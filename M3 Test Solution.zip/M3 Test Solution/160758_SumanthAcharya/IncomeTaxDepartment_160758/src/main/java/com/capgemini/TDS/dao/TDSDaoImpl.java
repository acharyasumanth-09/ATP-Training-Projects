package com.capgemini.TDS.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.capgemini.TDS.entity.Client;

@Repository
public class TDSDaoImpl implements TDSDao {

	@Autowired
	private MongoTemplate mongoTemplate;

	/*Method Name = getTdsDetailsById.
	 *Description = This method is used to fetch TDS Details of only a specific ID from ITdb database created in MongoDB.
	 *Author = Capgemini
	 *Creation Date = 03rd December 2018
	 */
	@Override
	public Client getTdsDetailsById(String unique_id) {
		Query query = new Query();
		query.addCriteria(Criteria.where("_id").is(unique_id));
		return mongoTemplate.findOne(query, Client.class);
	}

}
