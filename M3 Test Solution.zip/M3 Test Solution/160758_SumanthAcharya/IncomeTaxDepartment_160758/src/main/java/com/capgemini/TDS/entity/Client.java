package com.capgemini.TDS.entity;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="tdsdetail")
public class Client {

	@Id
	private String unique_id;

	@NotNull
	@Size(min = 2, message = "Deductor Name should have atleast 2 characters")
	private String deductor_name;

	@NotNull(message = "Deductor Pan cannot be Null")
	private String deductor_pan;

	@NotNull(message = "TDS Deposited field cannot be Null")
	private String tds_deposited;

	//Getters and Setters for the above variables
	public String getUnique_id() {
		return unique_id;
	}

	public void setUnique_id(String unique_id) {
		this.unique_id = unique_id;
	}

	public String getDeductor_name() {
		return deductor_name;
	}

	public void setDeductor_name(String deductor_name) {
		this.deductor_name = deductor_name;
	}

	public String getDeductor_pan() {
		return deductor_pan;
	}

	public void setDeductor_pan(String deductor_pan) {
		this.deductor_pan = deductor_pan;
	}

	public String getTds_deposited() {
		return tds_deposited;
	}	

	public void setTds_deposited(String tds_deposited) {
		this.tds_deposited = tds_deposited;
	}
}