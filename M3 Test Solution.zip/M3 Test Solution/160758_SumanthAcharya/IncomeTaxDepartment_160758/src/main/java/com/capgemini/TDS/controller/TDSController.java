package com.capgemini.TDS.controller;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.TDS.entity.Client;
import com.capgemini.TDS.exception.IDNotFoundException;
import com.capgemini.TDS.service.TDSService;

@RestController
@RequestMapping(value = "/")
public class TDSController {

	private final Logger LOG = LoggerFactory.getLogger(getClass());

	@Autowired
	private TDSService tdsService;

	/*Method Name = getTdsDetailsById.
	 *Description = This method is used to fetch TDS Details of only a specific ID from ITdb database created in MongoDB.
	 *Author = Capgemini
	 *Creation Date = 03rd December 2018
	 */
	@RequestMapping(value = "/find/{unique_id}", method = RequestMethod.GET)
	public Client getTdsDetailsById(@PathVariable String unique_id) {
		LOG.info("Getting TDS Details with ID : {}...", unique_id);
		Client client = tdsService.getTdsDetailsById(unique_id);
		if (client == null) {
			throw new IDNotFoundException(" ID Not Found, Wrong ID : "
					+ unique_id);
		}
		return client;
	}

}
