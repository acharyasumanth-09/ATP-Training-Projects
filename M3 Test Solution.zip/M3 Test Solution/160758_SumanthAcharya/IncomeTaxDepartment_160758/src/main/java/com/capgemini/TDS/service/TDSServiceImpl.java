package com.capgemini.TDS.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.TDS.dao.TDSDao;
import com.capgemini.TDS.entity.Client;

@Service
public class TDSServiceImpl implements TDSService {

	@Autowired
	private TDSDao tdsDao;

	/*Method Name = getTdsDetailsById.
	 *Description = This method is used to fetch TDS Details of only a specific ID from ITdb database created in MongoDB.
	 *Author = Capgemini
	 *Creation Date = 03rd December 2018
	 */
	@Override
	public Client getTdsDetailsById(String unique_id) {
		return tdsDao.getTdsDetailsById(unique_id);
	}

}
