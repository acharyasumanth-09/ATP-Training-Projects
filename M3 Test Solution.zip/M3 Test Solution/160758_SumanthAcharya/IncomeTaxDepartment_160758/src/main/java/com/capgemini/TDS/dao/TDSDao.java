package com.capgemini.TDS.dao;

import java.util.List;

import com.capgemini.TDS.entity.Client;

public interface TDSDao {

	Client getTdsDetailsById(String unique_id);

}