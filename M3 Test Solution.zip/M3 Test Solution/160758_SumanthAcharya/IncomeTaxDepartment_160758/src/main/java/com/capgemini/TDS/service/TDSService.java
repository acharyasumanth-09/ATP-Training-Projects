package com.capgemini.TDS.service;

import java.util.List;

import com.capgemini.TDS.entity.Client;

public interface TDSService {

	Client getTdsDetailsById(String unique_id);

}