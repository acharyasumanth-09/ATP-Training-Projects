package com.cg.btva.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.btva.beans.BusDetails;

@Repository
@Transactional
public class BusDAOImpl implements IBusDAO{

	@PersistenceContext
	EntityManager manager;

	
	/*
	 * methodName = getAllBusDetails
	 * arguments = null
	 * return type  = list
	 * Author = Capgemini
	 * creationDate = 13/11/2018 
	 * this method is used to get all bus details from Bus Details Table
	 * 
	 * */
	
	
	@Override
	public List<BusDetails> getBusDetails() {
		TypedQuery<BusDetails> query = manager.createQuery(
				"SELECT d FROM  BusDetails d", BusDetails.class);
		return query.getResultList();
	}
}
