package com.cg.btva.dao;

import java.util.List;

import com.cg.btva.beans.BusDetails;

public interface IBusDAO {

	
	List<BusDetails> getBusDetails();

}
