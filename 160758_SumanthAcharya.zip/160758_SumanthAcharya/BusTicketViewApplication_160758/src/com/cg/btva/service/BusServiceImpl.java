package com.cg.btva.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.btva.beans.BusDetails;
import com.cg.btva.dao.IBusDAO;

@Service
public class BusServiceImpl implements IBusService{

	@Autowired
	IBusDAO dao ;
	
	

	public IBusDAO getDao() {
		return dao;
	}



	public void setDao(IBusDAO dao) {
		this.dao = dao;
	}


	/*
	 * methodName = getAllBusDetails
	 * arguments = null
	 * return type  = list
	 * Author = Capgemini
	 * creationDate = 13/11/2018 
	 * this method is used to pass control to dao and get all bus details from Bus Details Table
	 * 
	 * */
	
	@Override
	public List<BusDetails> getBusDetails() {
		return dao.getBusDetails();
	}
}