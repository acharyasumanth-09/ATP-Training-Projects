package com.cg.btva.service;

import java.util.List;

import com.cg.btva.beans.BusDetails;

public interface IBusService {

	List<BusDetails> getBusDetails();

}
