package com.cg.btva.exception;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

@ControllerAdvice
public class BusExceptionHandling {

	@ExceptionHandler(value = { Exception.class })
	public ModelAndView busExHandling(Exception exception) {
		String message = exception.getMessage();
		return new ModelAndView("error", "message", message);

	}
}
