package com.cg.btva.exception;

public class BusExceptions extends Exception {

	private static final long serialVersionUID = 1L;

	public BusExceptions() {
	}

	public BusExceptions(String arg0) {
		super(arg0);
	}

}
