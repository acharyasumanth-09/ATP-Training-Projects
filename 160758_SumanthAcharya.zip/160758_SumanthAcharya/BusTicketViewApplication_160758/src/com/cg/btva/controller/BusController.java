package com.cg.btva.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.btva.beans.BusDetails;
import com.cg.btva.exception.BusExceptions;
import com.cg.btva.service.IBusService;

@Controller
public class BusController {

	@Autowired
	IBusService service;

	public IBusService getService() {
		return service;
	}

	public void setService(IBusService service) {
		this.service = service;
	}

	@RequestMapping("/BusDetails")
	public ModelAndView showHomePage() throws BusExceptions {
		ModelAndView view = new ModelAndView();
		try {
			List<BusDetails> list = service.getBusDetails();
			if (list.isEmpty()) {
				throw new BusExceptions();
			}
			view.setViewName("BusDetails");
			view.addObject("list", list);
		} catch (Exception e) {
			throw new BusExceptions("No Bus Details Found!!!");
		}
		return view;
	}
}
