package com.capgemini.fms.model;

public class FeedbackEntry {
	private String trainingCode;
	private String participantId;
	private String presComm;
	private String clrfyDbts;
	private String timeMgmt;
	private String handOut;
	private String hwSwNtwrk;
	private String comments;
	private String suggestions;
	
	public FeedbackEntry() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FeedbackEntry(String trainingCode, String participantId,
			String presComm, String clrfyDbts, String timeMgmt, String handOut,
			String hwSwNtwrk, String comments, String suggestions) {
		super();
		this.trainingCode = trainingCode;
		this.participantId = participantId;
		this.presComm = presComm;
		this.clrfyDbts = clrfyDbts;
		this.timeMgmt = timeMgmt;
		this.handOut = handOut;
		this.hwSwNtwrk = hwSwNtwrk;
		this.comments = comments;
		this.suggestions = suggestions;
	}

	public FeedbackEntry(String presComm, String clrfyDbts, String timeMgmt,
			String handOut, String hwSwNtwrk, String comments,
			String suggestions) {
		super();
		this.presComm = presComm;
		this.clrfyDbts = clrfyDbts;
		this.timeMgmt = timeMgmt;
		this.handOut = handOut;
		this.hwSwNtwrk = hwSwNtwrk;
		this.comments = comments;
		this.suggestions = suggestions;
	}

	public String getTrainingCode() {
		return trainingCode;
	}

	public void setTrainingCode(String trainingCode) {
		this.trainingCode = trainingCode;
	}

	public String getParticipantId() {
		return participantId;
	}

	public void setParticipantId(String participantId) {
		this.participantId = participantId;
	}

	public String getPresComm() {
		return presComm;
	}

	public void setPresComm(String presComm) {
		this.presComm = presComm;
	}

	public String getClrfyDbts() {
		return clrfyDbts;
	}

	public void setClrfyDbts(String clrfyDbts) {
		this.clrfyDbts = clrfyDbts;
	}

	public String getTimeMgmt() {
		return timeMgmt;
	}

	public void setTimeMgmt(String timeMgmt) {
		this.timeMgmt = timeMgmt;
	}

	public String getHandOut() {
		return handOut;
	}

	public void setHandOut(String handOut) {
		this.handOut = handOut;
	}

	public String getHwSwNtwrk() {
		return hwSwNtwrk;
	}

	public void setHwSwNtwrk(String hwSwNtwrk) {
		this.hwSwNtwrk = hwSwNtwrk;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getSuggestions() {
		return suggestions;
	}

	public void setSuggestions(String suggestions) {
		this.suggestions = suggestions;
	}	
}
