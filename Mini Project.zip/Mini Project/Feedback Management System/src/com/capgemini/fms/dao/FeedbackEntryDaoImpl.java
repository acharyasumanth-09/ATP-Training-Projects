package com.capgemini.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capgemini.fms.exception.FMSException;
import com.capgemini.fms.model.FeedbackEntry;
import com.capgemini.fms.utility.jdbcUtility;

public class FeedbackEntryDaoImpl implements IFeedbackEntryDao {

	Connection connection = null;
	PreparedStatement statement = null;
	
	/*
	 * methodName - getTrainingCode 
	 * arguments - String trainingCode 
	 * return type - boolean 
	 * Author - Capgemini 
	 * description - this method is used to get the trainingCode from the training_program_master table present in database
	 */
	@Override
	public boolean getTrainingCode(String trainingCode) throws FMSException {
		boolean flag = false;
		connection = jdbcUtility.getConnection();
		try {
			statement = connection.prepareStatement(QueryConstant.Get_TrainingCode);
			
			ResultSet resultset = statement.executeQuery();
	
			while(resultset.next()){
				String trCode = resultset.getString(1);
				if(trainingCode.equals(trCode))
				{
					flag=true;
					break;
				}
			}
			resultset.close();
		} catch (SQLException e) {
			throw new FMSException("Unable To find Training Code");
		}finally{
				try {
					statement.close();
				} catch (SQLException e) {
					throw new FMSException("Unable To close statement");
				}
				try {
					connection.close();
				} catch (SQLException e) {
					throw new FMSException("Unable To close connection");
				}
		}
		return flag;
	}
	
	/*
	 * methodName - getParticipantId 
	 * arguments - String participantId 
	 * return type - boolean 
	 * Author - Capgemini 
	 * description - this method is used to get the participantId from the employee_master table present in database
	 */
	@Override
	public boolean getParticipantId(String participantId) throws FMSException {
		boolean flag1 = false;
		connection = jdbcUtility.getConnection();
		try {
			statement = connection.prepareStatement(QueryConstant.Get_ParticipantId);
			
			ResultSet resultset1 = statement.executeQuery();
	
			while(resultset1.next()){
				String parId = resultset1.getString(1);
				if(participantId.equals(parId))
				{
					flag1=true;
					break;
				}
			}
			resultset1.close();
		} catch (SQLException e) {
			throw new FMSException("Unable To find Participant Code");
		}finally{
			try {
				statement.close();
			} catch (SQLException e) {
				throw new FMSException("Unable To close statement");
			}
			try {
				connection.close();
			} catch (SQLException e) {
				throw new FMSException("Unable To close connection");
			}
		}
		return flag1;
	}
	
	/*
	 * methodName - feedbackEntry 
	 * arguments - FeedbackEntry Object 
	 * return type - boolean 
	 * Author - Capgemini 
	 * description - this method is used to insert the feedback details into the database
	 */
	@Override
	public boolean feedbackEntry(FeedbackEntry fbentry) throws FMSException {
		boolean flag = false;
		
		if (fbentry != null) {
			try {
				connection = jdbcUtility.getConnection();
				try {
					statement = connection.prepareStatement(QueryConstant.GIVE_FEEDBACK);
					statement.setString(1, fbentry.getTrainingCode());
					statement.setString(2, fbentry.getParticipantId());
					statement.setString(3, fbentry.getPresComm());
					statement.setString(4, fbentry.getClrfyDbts());
					statement.setString(5, fbentry.getTimeMgmt());
					statement.setString(6, fbentry.getHandOut());
					statement.setString(7, fbentry.getHwSwNtwrk());
					statement.setString(8, fbentry.getComments());
					statement.setString(9, fbentry.getSuggestions());
					
					int result = statement.executeUpdate();

					if (result > 0) {
						
						flag = true;
					}connection.commit();
				} catch (SQLException e) {
					throw new FMSException("Unable To Create Statement");
				}finally{
					statement.close();
				}
			} catch (SQLException e) {
				throw new FMSException("Unable To Create Connection");
			}finally{
				try {
					connection.close();
				} catch (SQLException e) {
					throw new FMSException("Unable To Close Connection");
				}
			}
		}
		return flag;
	}
}
