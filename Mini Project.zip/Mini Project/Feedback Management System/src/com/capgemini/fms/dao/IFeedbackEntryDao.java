package com.capgemini.fms.dao;

import com.capgemini.fms.exception.FMSException;
import com.capgemini.fms.model.FeedbackEntry;

public interface IFeedbackEntryDao {
	
	boolean getTrainingCode(String trainingCode) throws FMSException;
	
	boolean getParticipantId(String participantId) throws FMSException;
	
	boolean feedbackEntry(FeedbackEntry fbentry) throws FMSException;
}
