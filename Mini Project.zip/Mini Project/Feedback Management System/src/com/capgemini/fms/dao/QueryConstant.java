package com.capgemini.fms.dao;

public interface QueryConstant {

	public static final String GIVE_FEEDBACK="INSERT INTO feedback_master VALUES(?,?,?,?,?,?,?,?,?)";
	
	public static final String Get_TrainingCode="SELECT training_code FROM training_program_master";
	
	public static final String Get_ParticipantId="SELECT participant_id FROM employee_master";
	
}
