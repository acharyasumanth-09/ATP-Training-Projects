package com.capgemini.fms.service;

import com.capgemini.fms.dao.FeedbackEntryDaoImpl;
import com.capgemini.fms.dao.IFeedbackEntryDao;
import com.capgemini.fms.exception.FMSException;
import com.capgemini.fms.model.FeedbackEntry;

public class FeedbackEntryServiceImpl implements IFeedbackEntryService {

	private IFeedbackEntryDao entryDao;
	
	public FeedbackEntryServiceImpl() {
		entryDao=new FeedbackEntryDaoImpl();
	}
	
	/*
	 * methodName - getTrainingCode 
	 * arguments - String trainingCode 
	 * return type - boolean 
	 * Author - Capgemini 
	 * description - this method is used to get the trainingCode from the training_program_master table present in database
	 */
	@Override
	public boolean getTrainingCode(String trainingCode) throws FMSException {
		return entryDao.getTrainingCode(trainingCode);
	}

	/*
	 * methodName - getParticipantId 
	 * arguments - String participantId 
	 * return type - boolean 
	 * Author - Capgemini 
	 * description - this method is used to get the participantId from the employee_master table present in database
	 */
	@Override
	public boolean getParticipantId(String participantId) throws FMSException {
		return entryDao.getParticipantId(participantId);
	}
	
	/*
	 * methodName - feedbackEntry 
	 * arguments - FeedbackEntry Object 
	 * return type - boolean 
	 * Author - Capgemini 
	 * description - this method is used to insert the feedback details into the database
	 */
	@Override
	public boolean feedbackEntry(FeedbackEntry fbentry) throws FMSException {
		return entryDao.feedbackEntry(fbentry);
	}
}
