package com.capgemini.fms.ui;

import java.util.Scanner;

import com.capgemini.fms.exception.FMSException;
import com.capgemini.fms.model.FeedbackEntry;
import com.capgemini.fms.service.FeedbackEntryServiceImpl;
import com.capgemini.fms.service.IFeedbackEntryService;

public class TraineeConsole {

	static Scanner scanner = new Scanner(System.in);
	static IFeedbackEntryService fbEntryService = new FeedbackEntryServiceImpl();
	
	public static void main(String[] args) {
		
		System.out.println("-------------------------Welcome Trainee-------------------------");
		System.out.println("\n");
		System.out.println("Give your FeedBack for the Training Program Below");
		System.out.println("\n");
		System.out.println("************************Rating Terminology***********************");
		System.out.println("-----------------------------------------------------------------");
		System.out.println("5-Excellent: 'Ideal way of doing it'\n"+
						   "4-Good: 'No pain areas or concern but could have been better'\n"+
						   "3-Average: 'There are concerns but not significant'\n"+
						   "2-Below Average: 'Needs improvement and is salvageable'\n"+
						   "1-Poor: 'This way of doing things must change'");
		System.out.println("-----------------------------------------------------------------");
		
		FeedbackEntry fbentry = giveFeedback();
		
		try{
			boolean result = fbEntryService.feedbackEntry(fbentry);		
			if (result) {
				System.out.println("      Thankyou for giving the Feedback     ");
				System.out.println("Your Feedback has been Successfully Recorded");
			} else {
				System.err.println("Unable to Record FeedBack");
			}
		}catch (FMSException e) {
			System.err.println(e.getMessage());
		}
	}

	private static FeedbackEntry giveFeedback() {
		FeedbackEntry fbentry=null;
		System.out.println("Enter the Training Code");
		String trainingCode = scanner.nextLine();
		try {
			boolean result=fbEntryService.getTrainingCode(trainingCode);
			if(result){
				System.out.println("Enter the Participant ID");
				String participantId = scanner.nextLine();
				try {
					boolean result1=fbEntryService.getParticipantId(participantId);
					if(result1){
						System.out.println("---------------------------------------------------------------------------------");
						System.out.println("Enter your Feedback details (Give your ratings for the below fields out of 5)");
						System.out.println("---------------------------------------------------------------------------------");
						System.out.println("Presentation and Communication Skills of Faculty");
						String presComm = scanner.nextLine();
						System.out.println("Ability to clarify doubts and explain difficult points");
						String clrfyDbts = scanner.nextLine();
						System.out.println("Time management in completing the contents ");
						String timeMgmt = scanner.nextLine();
						System.out.println("Handout provided(Student Guide)");
						String handOut = scanner.nextLine();
						System.out.println("Hardware, software and network availability");
						String hwSwNtwrk = scanner.nextLine();
						System.out.println("Comments");
						String comments = scanner.nextLine();
						System.out.println("Suggestions");
						String suggestions = scanner.nextLine();
						
						fbentry = new FeedbackEntry(trainingCode, participantId, presComm, clrfyDbts, timeMgmt, handOut, hwSwNtwrk, comments, suggestions);
					}
					else
					{
						System.err.println("You are not a Participant to this training code");
					}
				} catch (FMSException e) {
					System.err.println(e.getMessage());
				}
			}
			else
			{
				System.err.println("Training code not avaialble");
			}
		} catch (FMSException e) {
			System.err.println(e.getMessage());
		}
		return fbentry;
	}
}
