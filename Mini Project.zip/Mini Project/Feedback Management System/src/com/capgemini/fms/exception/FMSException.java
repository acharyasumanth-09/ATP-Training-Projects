package com.capgemini.fms.exception;

public class FMSException extends Exception {

	public FMSException(String errMsg) {
		super(errMsg);
	}
}
