package com.cg.fms.model;

public class feedbackBean {
	private String tariningCode;
	private String participantId;
	private String fbPrsComm;
	private String fbClrfyDbts;
	private String fbTm;
	private String fbHndOut;
	private String fbHwSwNtwrk;
	private String comments;
	private String suggestions;
	public String getTariningCode() {
		return tariningCode;
	}
	public void setTariningCode(String tariningCode) {
		this.tariningCode = tariningCode;
	}
	public String getParticipantId() {
		return participantId;
	}
	public void setParticipantId(String participantId) {
		this.participantId = participantId;
	}
	public String getFbPrsComm() {
		return fbPrsComm;
	}
	public void setFbPrsComm(String fbPrsComm) {
		this.fbPrsComm = fbPrsComm;
	}
	public String getFbClrfyDbts() {
		return fbClrfyDbts;
	}
	public void setFbClrfyDbts(String fbClrfyDbts) {
		this.fbClrfyDbts = fbClrfyDbts;
	}
	public String getFbTm() {
		return fbTm;
	}
	public void setFbTm(String fbTm) {
		this.fbTm = fbTm;
	}
	public String getFbHndOut() {
		return fbHndOut;
	}
	public void setFbHndOut(String fbHndOut) {
		this.fbHndOut = fbHndOut;
	}
	public String getFbHwSwNtwrk() {
		return fbHwSwNtwrk;
	}
	public void setFbHwSwNtwrk(String fbHwSwNtwrk) {
		this.fbHwSwNtwrk = fbHwSwNtwrk;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getSuggestions() {
		return suggestions;
	}
	public void setSuggestions(String suggestions) {
		this.suggestions = suggestions;
	}
	public feedbackBean(String tariningCode, String participantId,
			String fbPrsComm, String fbClrfyDbts, String fbTm, String fbHndOut,
			String fbHwSwNtwrk, String comments, String suggestions) {
		super();
		this.tariningCode = tariningCode;
		this.participantId = participantId;
		this.fbPrsComm = fbPrsComm;
		this.fbClrfyDbts = fbClrfyDbts;
		this.fbTm = fbTm;
		this.fbHndOut = fbHndOut;
		this.fbHwSwNtwrk = fbHwSwNtwrk;
		this.comments = comments;
		this.suggestions = suggestions;
	}
	
public feedbackBean() {
	
}
}
