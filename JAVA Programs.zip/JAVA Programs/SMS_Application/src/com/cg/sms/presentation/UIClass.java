package com.cg.sms.presentation;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.cg.sms.model.Student;
import com.cg.sms.service.StudentService;
import com.cg.sms.service.StudentServiceImpl;

public class UIClass 
{
	public static void main(String[] args) 
	{
		Scanner scanner = new Scanner(System.in);
		System.out.println("Available Operations:-");
		System.out.println("----------------------------");
		System.out.println("1.Insert Student");
		System.out.println("2.Delete Student");
		System.out.println("3.Update Student Details");
		System.out.println("4.Select All Student");
		System.out.println("5.Select Student by ID : ");
		System.out.println("-----------------------------");
		System.out.println("Select Your Choice:");
		int input = scanner.nextInt();
		
		StudentService service = new StudentServiceImpl();
		
		switch(input)
		{
		case 1:
			scanner.nextLine();
			System.out.println("Enter Name :");
			String name = scanner.nextLine();
			System.out.println("Enter Designation :");
			String desig = scanner.nextLine();
			System.out.println("Enter Salary :");
			double salary = scanner.nextDouble();
			
			Student student = new Student();
			student.setName(name);
			student.setDesignation(desig);
			student.setSalary(salary);
		
			
			int result;
			try{
				result = service.addstudent(student);
				System.out.println(result + " Inserted..");
			}catch(ClassNotFoundException | SQLException |IOException e)
			{
				e.printStackTrace();
			}
			break;
			
		case 2:
			System.out.println("Enter id to delete :");
			int studentId = scanner.nextInt();

			int res;
			try {
				res = service.deletestudent(studentId);
				System.out.println(res + " record deleted with id : " + studentId);
			} catch (ClassNotFoundException | SQLException | IOException e1) {
				e1.printStackTrace();
			}

			break;
		
		case 3:

			System.out.println("Enter id :");
			int id = scanner.nextInt();
			scanner.nextLine();
			System.out.println("Enter designation to update :");
			String designation = scanner.nextLine();

			Student student2 = new Student();
			student2.setId(id);
			student2.setDesignation(designation);

			try {
				int result1 = service.updateStudent(student2);
				System.out.println(result1 + " updated with id : " + id);
			} catch (ClassNotFoundException | IOException | SQLException e) {
				e.printStackTrace();
			}

			break;
		
		case 4:
			try {
				List<Student> list = service.getAllStudents();

				for (Student student3 : list) {
					System.out.println(student3.getId() + " : " + student3.getName() + " : " + student3.getDesignation() + " : "
							+ student3.getSalary());
				}

			} catch (ClassNotFoundException | IOException | SQLException e) {
				e.printStackTrace();
			}

			break;
		
		case 5:
			break;
			
		}
;
		}
}
