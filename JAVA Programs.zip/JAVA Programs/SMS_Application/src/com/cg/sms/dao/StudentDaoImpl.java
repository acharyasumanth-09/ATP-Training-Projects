package com.cg.sms.dao;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.sms.constants.QueryConstants;
import com.cg.sms.model.Student;
import com.cg.sms.utility.JdbcUtility;

public class StudentDaoImpl implements StudentDao {
	Connection connection = null;
	PreparedStatement statement = null;

	@Override
	public int addstudent(Student student) throws SQLException,
			ClassNotFoundException, FileNotFoundException, IOException {
		connection = JdbcUtility.getConnection();
		String query = QueryConstants.insertQuery;
		statement = connection.prepareStatement(query);
		statement.setString(1, student.getName());
		statement.setString(3, student.getDesignation());
		statement.setDouble(2, student.getSalary());

		int result = statement.executeUpdate();
		return result;
	}

	@Override
	public int deletestudent(int id) throws SQLException,
			ClassNotFoundException, FileNotFoundException, IOException {
		connection = JdbcUtility.getConnection();
		statement = connection.prepareStatement(QueryConstants.deleteQuery);
		statement.setInt(1, id);

		int res = statement.executeUpdate();
		return res;
	}

	@Override
	public int updateStudent(Student student) throws SQLException,
			ClassNotFoundException, FileNotFoundException, IOException {
		connection = JdbcUtility.getConnection();
		statement = connection.prepareStatement(QueryConstants.updateQuery);
		statement.setString(1, student.getDesignation());
		statement.setInt(2, student.getId());

		int res = statement.executeUpdate();
		return res;
	}

	@Override
	public List<Student> getAllStudents() throws SQLException,
			ClassNotFoundException, FileNotFoundException, IOException {
		List<Student> list = new ArrayList<>();

		connection = JdbcUtility.getConnection();

		statement = connection.prepareStatement(QueryConstants.selectQuery);

		ResultSet resultSet = statement.executeQuery();

		while (resultSet.next()) {

			int id = resultSet.getInt(1);
			String name = resultSet.getString(2);
			String designation = resultSet.getString(4);
			double salary = resultSet.getDouble(3);

			Student student = new Student(id, name, designation, salary);
			list.add(student);
		}

		return list;
	}

}
