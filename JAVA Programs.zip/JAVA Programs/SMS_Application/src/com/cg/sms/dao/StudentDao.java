package com.cg.sms.dao;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.cg.sms.model.Student;

public interface StudentDao 
{
	public int addstudent(Student student)throws SQLException, ClassNotFoundException, FileNotFoundException, IOException;
	public int deletestudent(int id)throws SQLException, ClassNotFoundException, FileNotFoundException, IOException;
	public int updateStudent(Student student) throws SQLException, ClassNotFoundException, FileNotFoundException, IOException;
	public List<Student> getAllStudents() throws SQLException, ClassNotFoundException, FileNotFoundException, IOException;
}

