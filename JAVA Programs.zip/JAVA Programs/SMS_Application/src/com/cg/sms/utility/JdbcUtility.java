package com.cg.sms.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class JdbcUtility 
{
	private static Connection connection = null;
	public static Connection getConnection() throws SQLException, ClassNotFoundException, FileNotFoundException, IOException
	{
		Properties properties = new Properties();
		
		properties.load(new FileInputStream(new File("resources/jdbc.properties")));
		
		String Driver = properties.getProperty("db.driver");
		String URL = properties.getProperty("db.url");
		String Username = properties.getProperty("db.username");
		String Password = properties.getProperty("db.password");
		
		Class.forName(Driver);
		connection = DriverManager.getConnection(URL,Username,Password);
		return connection;
	}
}
