package com.cg.sms.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.cg.sms.dao.StudentDao;
import com.cg.sms.dao.StudentDaoImpl;
import com.cg.sms.model.Student;

public class StudentServiceImpl implements StudentService
{
	StudentDao studentdao = new StudentDaoImpl();

	@Override
	public int addstudent(Student student)throws SQLException, ClassNotFoundException, FileNotFoundException, IOException 
	{
		return studentdao.addstudent(student);
	}

	@Override
	public int deletestudent(int id)throws SQLException, ClassNotFoundException, FileNotFoundException, IOException 
	{
		return studentdao.deletestudent(id);
	}

	@Override
	public int updateStudent(Student student) throws SQLException,
			ClassNotFoundException, FileNotFoundException, IOException 
	{	
		int result1 = studentdao.updateStudent(student);
		return result1;
	}

	@Override
	public List<Student> getAllStudents() throws SQLException,
			ClassNotFoundException, FileNotFoundException, IOException {
		List<Student> list = studentdao.getAllStudents();
		return list;
	}

	
	
	
}
