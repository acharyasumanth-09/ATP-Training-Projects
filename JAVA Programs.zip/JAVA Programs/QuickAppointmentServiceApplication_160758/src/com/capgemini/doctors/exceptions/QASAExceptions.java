package com.capgemini.doctors.exceptions;

public class QASAExceptions extends Exception {

	private String message;

	public QASAExceptions(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}
}
