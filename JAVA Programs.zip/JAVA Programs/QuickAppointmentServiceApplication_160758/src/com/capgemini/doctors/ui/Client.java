/*package com.capgemini.doctors.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDao;
import com.capgemini.doctors.exceptions.QASAExceptions;
import com.capgemini.doctors.service.DoctorAppointmentService;
import com.capgemini.doctors.service.IDoctorAppointmentService;

public class Client {
	
	static Logger logger = Logger.getLogger(DoctorAppointmentDao.class);
	static Scanner scanner = new Scanner(System.in);
	
	public static void main(String[] args) {
		
		IDoctorAppointmentService doctorAppointmentService = new DoctorAppointmentService();
		PropertyConfigurator.configure("resources/log4j.properties");
		logger.info("log4j.configured");
		
		System.out.println("-------------------------------------");
		System.out.println("Quick Appointment Service Application");
		System.out.println("-------------------------------------");
		
		System.out.println("1. Book Doctor Appointment");
		System.out.println("2. Exit");
		
		System.out.println("-------------------------------------");
		System.out.println("Select your choice");
		int option = 0;
		
		try{
			option = scanner.nextInt();
		}catch(InputMismatchException e){
			System.err.println("Enter digits only either 1 or 2");
			System.exit(0);
		}
		
		switch(option){
		
		case 1 : Client client = newClient();
				 
			try{
				boolean result = IDoctorAppointmentService.validateDoctorAppointment(doctorAppointmentService);
				if(result){
					boolean resultFlag = IDoctorAppointmentService.validateDoctorAppointment(doctorAppointmentService);
				}
					if(resultFlag)
					{
						int id = IDoctorAppointmentService.getMaxAppointmentId();
						System.out.println("Your Appointment has been successfully registered, your apointment ID is : "+id);
					}else{
						System.out.println("Appointment not confirmed");
					}
			}catch(QASAExceptions e){
				System.err.println(e.getMessage());
			}
			break;
		
		case 2 :  System.exit(0);
//				  break;
		}

		private static Client newClient() {
			scanner.nextLine();
			System.out.println("Enter NAme Of the Patient :");
			String patientName = scanner.nextLine();
			System.out.println("Enter Phone Number :");
			Long phoneNumber = scanner.nextLong();
			System.out.println("Enter email :");
			String email = scanner.nextLine();
			System.out.println("Enter Age :");
			int age = scanner.nextInt();
			System.out.println("Enter gender :");
			String gender = scanner.nextLine();
			System.out.println("Enter Problem Name :");
			String problemName = scanner.nextLine();
			
//			DoctorAppointment doctorAppointment = new IDoctorAppointmentDAo(patientName,phoneNumber,email,age,gender,problemName); 
			return doctorAppointment;
//	}

}
*/