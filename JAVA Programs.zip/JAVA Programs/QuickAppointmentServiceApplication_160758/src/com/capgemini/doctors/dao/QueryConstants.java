package com.capgemini.doctors.dao;

public interface QueryConstants {
	
	public static final String insertDoctorAppointment = "insert into doctor_appointment values(seq_appointment_id.nextval,?,?,?,?,?,?,sysdate+1)";
	
	public static final String selectMaxAppointmentId = "SELECT MAX (appointment_Id) FROM doctor_appointment";

}
