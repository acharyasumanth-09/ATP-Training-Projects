package com.capgemini.doctors.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exceptions.QASAExceptions;
import com.capgemini.doctors.utility.JdbcUtility;

public class DoctorAppointmentDao implements IDoctorAppointmentDao {
	
	static Logger logger = Logger.getLogger(DoctorAppointmentDao.class);
	Connection connection = null;
	PreparedStatement statement = null;
	
	@Override
	public int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment)
			throws QASAExceptions {
		connection = JdbcUtility.getConnection();
		logger.info("Connection Established");
		int result;
		
		try{
			statement = connection.prepareStatement(QueryConstants.insertDoctorAppointment);
			logger.debug("Statement Created");
			statement.setString(1,doctorAppointment.getPatientName());
			statement.setLong(2, doctorAppointment.getPhoneNumber());
			statement.setString(3,doctorAppointment.getEmail());
			statement.setInt(4,doctorAppointment.getAge());
			statement.setString(5,doctorAppointment.getGender());
			statement.setString(6,doctorAppointment.getProblemName());
			statement.setDate(7, doctorAppointment.getDateOfAppointment());
		}catch(SQLException e){
			logger.error("Statement object not created");
			throw new QASAExceptions("Statement not created due to some problems");
		}finally{
			JdbcUtility.closeConnection();
		}
		return result;
	}

}
