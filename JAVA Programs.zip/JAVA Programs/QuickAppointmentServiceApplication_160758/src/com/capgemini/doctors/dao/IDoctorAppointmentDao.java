package com.capgemini.doctors.dao;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exceptions.QASAExceptions;

public interface IDoctorAppointmentDao {

	public int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment)
			throws QASAExceptions;

}
