package com.capgemini.doctors.service;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exceptions.QASAExceptions;

public interface IDoctorAppointmentService {

	public int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment)
			throws QASAExceptions;

	boolean validateDoctorAppointment(DoctorAppointment doctorAppointment)
			throws QASAExceptions;

	public int getMaxAppointmentId();
}
