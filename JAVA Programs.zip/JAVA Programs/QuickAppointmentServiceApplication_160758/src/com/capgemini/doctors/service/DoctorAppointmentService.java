package com.capgemini.doctors.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDao;
import com.capgemini.doctors.dao.IDoctorAppointmentDao;
import com.capgemini.doctors.exceptions.QASAExceptions;

//public class DoctorAppointmentService implements IDoctorAppointmentService {
	
	IDoctorAppointmentDao appointmentDAo = new DoctorAppointmentDao();

	@Override
	public int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment)
			throws QASAExceptions {
		return appointmentDAo.addDoctorAppointmentDetails(doctorAppointment);
	}
	
	@Override
	public boolean validateDoctorAppointment(DoctorAppointment doctorAppointment) throws QASAExceptions{
		boolean flag = false;
		List<String>list = new ArrayList<>();
		
		if(!isPatientNameValid(doctorAppointment.getPatientName())){
			list.add("\n Patient Name should start with 'Capital Letters' only and should contain 'minimum 5' characters, Please enter only alphabets");
		}
		
		if(!isPhoneNumberValid(doctorAppointment.getPhoneNumber())){
			list.add("\n Phone Number should be '10 digits' only");
		}
		
		if(!isEmailValid(doctorAppointment.getEmail())){
			list.add("\n Enter a 'valid Email ID'");
		}
		
		if((!isEmailBlank(doctorAppointment.getEmail())|(!isAgeBlank(doctorAppointment.getAge())|(!isGenderBlank(doctorAppointment.getGender())|(!isProblemNameBlank(doctorAppointment.getProblemName()))))));{
			list.add("\n No fields must be left blank, Please fill all the fields");
		}
		
		if(!isDateOfAppointmentValid(doctorAppointment.getDateOfAppointment())){
			list.add("Appointment cannot be made for today, Please make an appoinment for tomorrow");
		}
		
		return flag;
	}

	
	private boolean isPatientNameValid(String patientName) {
		String patientNameRegEx = "[[A-Z]{1}[a-z]{24}]{5,25}";
		Pattern pattern = Pattern.compile(patientNameRegEx);
		Matcher matcher = pattern.matcher(patientName);
		return matcher.matches();
	}
	
	private boolean isPhoneNumberValid(long phoneNumber) {
		long phoneNumberRegEx = [0-9]{10};
		Pattern pattern1 = Pattern.compile(phoneNumberRegEx);
		Matcher matcher1 = pattern1.matcher(phoneNumber);
		return matcher1.matches();
	}
	
	private boolean isEmailValid(String email) {
		String emailRegEx = "^(.+)@(.+)$";
		Pattern pattern2 = Pattern.compile(emailRegEx);
		Matcher matcher2 = pattern2.matcher(email);
		return matcher2.matches();
	}
	
	private boolean isEmailBlank(String email) {
		String emailBlankRegEx = null;
		Pattern pattern3 = Pattern.compile(email);
		Matcher matcher3 = pattern3.matcher(email);
		return matcher3.matches();
	}
	
	private boolean isAgeBlank(int age) {
		int ageBlankRegEx = (Integer) null;
		Pattern pattern4 = Pattern.compile(ageBlankRegEx);
		Matcher matcher4 = pattern4.matcher(age);
		return matcher4.matches();
	}
	
	private boolean isGenderBlank(String gender) {
		String genderBlankRegEx = null;
		Pattern pattern5 = Pattern.compile(genderBlankRegEx);
		Matcher matcher5 = pattern5.matcher(gender);
		return matcher5.matches();
	}
	
	private boolean isProblemNameBlank(String problemName) {
		String problemNameBlankRegEx = null;
		Pattern pattern6 = Pattern.compile(problemNameBlankRegEx);
		Matcher matcher6 = pattern6.matcher(problemName);
		return matcher6.matches();
	}
	
	private boolean isDateOfAppointmentValid(Date dateOfAppointment) {
		
		return false;
	}


	

	
	

	
	
	

	
	

	
	
	
	

}
