package com.cg.mobile.dao.test;

public class MobileDaoTestImpl {

}
