package com.cg.mobile.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.cg.mobile.bean.Mobiles;
import com.cg.mobile.exception.MobileException;
import com.cg.mobile.utility.JdbcUtilityClass;

public class DaoImpl implements IDao {

	static Logger logger = Logger.getLogger(DaoImpl.class);
	Connection connection = null;
	PreparedStatement statement = null;

	@Override
	public boolean insertDetails(Mobiles mobiles) throws MobileException {

		logger.info("ConEstablished");
		boolean flag = false;

		try {
			connection = JdbcUtilityClass.getConnection();
			statement = connection
					.prepareStatement(QueryConstants.insertQuery1);
			logger.debug("Statement1 created");
			statement.setString(1, mobiles.getName());
			statement.setDouble(2, mobiles.getPrice());
			statement.setInt(3, mobiles.getQuantity());

			int result = statement.executeUpdate();

			if (result > 0) {
				logger.debug("Record Created");
				flag = true;
			}

		} catch (SQLException e) {
			logger.error("Statement object not created");
			throw new MobileException(
					"Statement not created due to some problem");
		} finally {
			JdbcUtilityClass.closeConnection();
		}
		return flag;
	}

	@Override
	public int getMaxId() throws MobileException {
		int id = 0;
		ResultSet resultSet = null;
		connection = JdbcUtilityClass.getConnection();
		try {
			statement = connection.prepareStatement(QueryConstants.idMaxQuery);
			resultSet = statement.executeQuery();
			
			resultSet.next();
			id = resultSet.getInt(1);
		} catch (SQLException e) {
			throw new MobileException("Unable to create statement");
		}finally{
			try {
				resultSet.close();
			} catch (SQLException e) {
				throw new MobileException("Problem while closing resultSet");
			}
			try {
				statement.close();
			} catch (SQLException e) {
				throw new MobileException("Problem while closing statement");
			}
			JdbcUtilityClass.closeConnection();
		}			
		return id;
	}

}
