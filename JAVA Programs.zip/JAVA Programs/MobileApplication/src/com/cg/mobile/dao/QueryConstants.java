package com.cg.mobile.dao;

public interface QueryConstants {

	
	public static final String insertQuery1="insert into mobiles values(idsequence.nextval,?,?,?)";
	public static final String  insertQuery2="insert into purchasedetails values(pidsequence.nextval,?,?,?,?,idsequence.CURRVAL)";
	public static final String idMaxQuery="select max(mobileid) from mobiles";
		
	}