package com.cg.mobile.presentation;

import java.util.Date;
import java.util.InputMismatchException;
import java.util.Scanner;

import oracle.sql.DATE;

import com.cg.mobile.bean.Mobiles;
import com.cg.mobile.bean.PurchaseDetails;
import com.cg.mobile.exception.MobileException;
import com.cg.mobile.service.IService;
import com.cg.mobile.service.ServiceImpl;

public class UIClass {

	public static void main(String[] args) {

		IService service = new ServiceImpl();
		Scanner scanner = new Scanner(System.in);
		boolean flag = false;
		System.out
				.println("*****************************************************\n");
		System.out
				.println("---------Welcome to Mobile Sales Application---------\n");
		System.out
				.println("-----------------------------------------------------\n");

		System.out.println("1. Create Account");
		System.out.println("2. Exit");
		System.out
				.println("***************************************************\n");

		System.out.println("Select your Choice");
		int option = 0;

		try {
			option = scanner.nextInt();
		} catch (Exception e) {
			System.err.println("Enter digits only (1/2)");
			System.exit(0);
		}

		switch (option) {
		case 1:

			scanner.nextLine();
			System.out.println("Enter the Mobile Name :");
			String mName = scanner.nextLine();
			System.out.println("Enter price :");
			double price = scanner.nextDouble();
			scanner.nextLine();
			System.out.println("Enter quantity :");
			int quantity = scanner.nextInt();

			/*
			 * System.out.println("Enter the Purchase Customer name :"); String
			 * cName = scanner.nextLine();
			 * System.out.println("Enter the Mail Id :"); String mail =
			 * scanner.nextLine();
			 * System.out.println("Enter the Mobile Number :"); String
			 * mno=scanner.nextLine();
			 */

			Mobiles mobiles = new Mobiles(mName, price, quantity);
			// PurchaseDetails pdetails=new PurchaseDetails(cName, mail, mno,
			// DATE.getCurrentDate(), mobiles)
			try {
				flag = service.insertDetails(mobiles);
				if (flag) {
					int id = service.getMaxId();
					System.out
							.println("Customer Account Created with mobile id: "
									+ id);
				} else {
					System.out.println("Customer Account Not Created");
				}
			} catch (MobileException e) {
				System.err.println("Record not inserted");
				System.out.println(e.getMessage());
			}

			break;
		case 2:
			System.out.println("Exiting Application...\n");
			System.out.println("Mobile Application terminated.\n");
			System.exit(0);
		default:
			System.out.println("Invalid choice, try again!\n");
		}

	}
}
