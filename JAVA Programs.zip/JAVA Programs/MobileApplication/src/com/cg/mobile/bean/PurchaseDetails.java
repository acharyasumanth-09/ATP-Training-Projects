package com.cg.mobile.bean;

import java.util.Date;

import oracle.sql.DATE;

public class PurchaseDetails {

	private String purchaseid;
	private String cname;
	private String mailid;
	private String phone;
	private DATE purchasedate;
	private Mobiles mobileid;

	public PurchaseDetails(String cName2, String mail, String mno, DATE date, Mobiles mobiles) {

	}

	protected PurchaseDetails(String purchaseid, String cname, String mailid,
			String phone, DATE purchasedate, Mobiles mobileid) {
		super();
		this.purchaseid = purchaseid;
		this.cname = cname;
		this.mailid = mailid;
		this.phone = phone;
		this.purchasedate = purchasedate;
		this.mobileid = mobileid;
	}

	public String getPurchaseid() {
		return purchaseid;
	}

	public void setPurchaseid(String purchaseid) {
		this.purchaseid = purchaseid;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getMailid() {
		return mailid;
	}

	public void setMailid(String mailid) {
		this.mailid = mailid;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public DATE getPurchasedate() {
		return purchasedate;
	}

	public void setPurchasedate(DATE purchasedate) {
		this.purchasedate = purchasedate;
	}

	public Mobiles getMobileid() {
		return mobileid;
	}

	public void setMobileid(Mobiles mobileid) {
		this.mobileid = mobileid;
	}

}
