package com.cg.mobile.service;

import com.cg.mobile.bean.Mobiles;
import com.cg.mobile.bean.PurchaseDetails;
import com.cg.mobile.dao.DaoImpl;
import com.cg.mobile.dao.IDao;
import com.cg.mobile.exception.MobileException;

public class ServiceImpl implements IService{

	IDao dao=new DaoImpl();
	@Override
	public boolean insertDetails(Mobiles mobiles) throws MobileException {
		
		
		return dao.insertDetails(mobiles);
	}

	@Override
	public int getMaxId() throws MobileException {
		return dao.getMaxId();
	}

}
