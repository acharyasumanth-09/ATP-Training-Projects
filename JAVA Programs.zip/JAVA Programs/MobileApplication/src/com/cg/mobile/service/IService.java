package com.cg.mobile.service;

import com.cg.mobile.bean.Mobiles;
import com.cg.mobile.exception.MobileException;

public interface IService {

	boolean insertDetails(Mobiles mobiles) throws MobileException;

	public int getMaxId() throws MobileException;

}
