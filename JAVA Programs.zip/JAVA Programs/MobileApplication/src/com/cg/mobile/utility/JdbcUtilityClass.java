package com.cg.mobile.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.mobile.exception.MobileException;

public class JdbcUtilityClass {

	private static Connection connection = null;

	public static Connection getConnection() throws MobileException {

		Properties properties = new Properties();
		try {
			properties.load(new FileInputStream(new File(
					"resources/jdbc.properties")));

			String driver = properties.getProperty("driver");
			String url = properties.getProperty("url");
			String username = properties.getProperty("username");
			String password = properties.getProperty("password");

			try {
				Class.forName(driver);
				connection = DriverManager.getConnection(url, username,
						password);
			} catch (ClassNotFoundException e) {
				throw new MobileException("Unable to throw the class");
			} catch (SQLException e) {
				throw new MobileException("Connection was not established");
			}

		} catch (IOException e) {
			throw new MobileException(
					"Unable to read the data from the File, Please Try Again");
		}
		return connection;
	}

	public static void closeConnection() throws MobileException {
		try {
			connection.close();
		} catch (SQLException e) {
			throw new MobileException("Unable to close the connection");
		}

	}
}
