package com.capgemini.mobile.bean;

import java.util.Date;

public class PurchaseDetails {
	
	private int purchaseId;
	private String cName;
	private String mailId;
	private long phoneNo;
	private Date purchaseDate;
	private Mobiles mobileId;
	
	public int getPurchaseId() {
		return purchaseId;
	}
	public void setPurchaseId(int purchaseId) {
		this.purchaseId = purchaseId;
	}
	public String getcName() {
		return cName;
	}
	public void setcName(String cName) {
		this.cName = cName;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}
	public Date getPurchaseDate() {
		return purchaseDate;
	}
	public void setPurchaseDate(Date purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
	public Mobiles getMobileId() {
		return mobileId;
	}
	public void setMobileId(Mobiles mobileId) {
		this.mobileId = mobileId;
	}
	public PurchaseDetails() {
		super();
		
	}
	public PurchaseDetails(int purchaseId, String cName, String mailId,
			long phoneNo, Date purchaseDate, Mobiles mobileId) {
		super();
		this.purchaseId = purchaseId;
		this.cName = cName;
		this.mailId = mailId;
		this.phoneNo = phoneNo;
		this.purchaseDate = purchaseDate;
		this.mobileId = mobileId;
	}
}
