package com.capgemini.mobile.bean;

public class Mobiles {
	
	private int mobileID;
	private String name;
	private double price;
	private String quantity;
	
	public int getMobileID() {
		return mobileID;
	}
	public void setMobileID(int mobileID) {
		this.mobileID = mobileID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public Mobiles() {
		super();
	
	}
	public Mobiles(int mobileID, String name, double price, String quantity) {
		super();
		this.mobileID = mobileID;
		this.name = name;
		this.price = price;
		this.quantity = quantity;
	}
}
