package com.capgemini.mobile.exception;

public class MOBAPPException extends Exception {
	private String message;

	public MOBAPPException(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

}
