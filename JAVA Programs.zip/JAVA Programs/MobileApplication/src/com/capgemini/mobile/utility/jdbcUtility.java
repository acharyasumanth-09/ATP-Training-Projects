package com.capgemini.mobile.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.capgemini.mobile.exception.MOBAPPException;

public class jdbcUtility {

	private static Connection connection = null;

	public static Connection getConnection() throws MOBAPPException {

		Properties properties = new Properties();
		try {
			properties.load(new FileInputStream(new File(
					"resources/jdbc.properties")));

			String driver = properties.getProperty("db.driver");
			String url = properties.getProperty("db.url");
			String username = properties.getProperty("db.username");
			String password = properties.getProperty("db.password");

			try {
				Class.forName(driver);
				connection = DriverManager.getConnection(url, username,
						password);
			} catch (ClassNotFoundException e) {
				throw new MOBAPPException("Unable to throw the class");
			} catch (SQLException e) {
				throw new MOBAPPException("Connection was not established");
			}

		} catch (IOException e) {
			throw new MOBAPPException(
					"Unable to read the data from the File, Please Try Again");
		}
		return connection;
	}

	public static void closeConnection() throws MOBAPPException {
		try {
			connection.close();
		} catch (SQLException e) {
			throw new MOBAPPException("Unable to close the connection");
		}

	}
}
