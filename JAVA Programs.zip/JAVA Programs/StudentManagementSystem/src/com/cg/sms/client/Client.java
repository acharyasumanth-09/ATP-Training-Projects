package com.cg.sms.client;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.cg.sms.doa.StudentDAO;
import com.cg.sms.doa.StudentDAOImpl;
import com.cg.sms.entity.Student;
import com.cg.sms.exception.StudentException;
import com.cg.sms.service.StudentService;
import com.cg.sms.service.StudentServiceImpl;

public class Client 
{
	public static void main(String[] args) throws StudentException
	{
		StudentService studentservice = new StudentServiceImpl();
		Student student = new Student();
		
		Scanner scanner = new Scanner(System.in);
		boolean x = true;
		do
		{
			System.out.println("Enter 1 for 'Adding Student Details'");
			System.out.println("Enter 2 to 'View the Student Details'");
			System.out.println("Enter 3 to 'Exit'");
		
		int choice = scanner.nextInt();
		switch(choice)
		{
		case 1 : System.out.println("Enter the Student Name (The First Letter of the Name should be in Capital)");
				 String studentName = scanner.next();
				 Pattern pattern1 = Pattern.compile("[A-Z]{1}[a-z]");
				 Matcher matcher1 = pattern1.matcher(studentName);
				 
				 if(matcher1.find())
				 {
					 student.setStudentName(studentName);
				 }
				 else
				 {
					 System.out.println("Invalid Entry, Please Enter the First Letter of the Name in Capital");
					 break;
				 }
				 
				 System.out.println("Enter the Student ID (Enter only Numeric Values and it should only be 6 Digits");
				 String studentId = scanner.next();
				 Pattern pattern2 = Pattern.compile("[1-9]{1}[0-9]{5}");
				 Matcher matcher2 = pattern2.matcher(studentId);
				 
				 if(matcher2.find())
				 {
					 int studId = Integer.parseInt(studentId);
					 student.setStudentId(studId);
				 }
				 else
				 {
					 System.out.println("Invalid Entry, Please Enter a Valid StudentId");
					 break;
				 }
				 
				 System.out.println("Enter Student Mobile Phone Number (It should be a 10 digit number");
				 String phoneNo = scanner.next();
				 Matcher matcher3 = Pattern.compile("[0-9]{10}").matcher(phoneNo);
				 
				 if(matcher3.matches())
				 {
					 long phNo = Long.parseLong(phoneNo);
					 student.setPhoneNo(phNo);
				 }
				 else
				 {
					 System.out.println("invalid Phone Number, Please Enter a 10 digit Student Mobile Phone Number");
					 break;
				 }
				 
				 System.out.println("Enter the City to which the Student belongs");
				 String City = scanner.next();
				 Matcher matcher4 = Pattern.compile("[A-Z]{1}[a-z]").matcher(City);
				 
				 if(matcher4.find())
				 {
					 student.setCity(City);
				 }
				 else
				 {
					 System.out.println("Please enter the first letter of the City in Capital");
				 }
				 
				 System.out.println("Enter the Student Email ID");
				 String emailId = scanner.next();
				 Matcher matcher5 = Pattern.compile("^(.*)@(.*)$").matcher(emailId);
				 
				 if(matcher5.find())
				 {
					 student.setEmailId(emailId);
				 }
				 else
				 {
					 System.out.println("Invalid Email ID, Please Enter Correct Email ID following the format of an Email ID");
					 break;
				 }
				 
				 studentservice.AddStudent(student);
				 break;
				 
		case 2 : studentservice.ViewDetails(student);
				 break;
				 
		case 3 : System.out.println("Terminating the Application.........");
				 System.out.println("Application Terminated Successfully");
				 System.exit(choice);
		
		}
		}while(x=true);
	}
}