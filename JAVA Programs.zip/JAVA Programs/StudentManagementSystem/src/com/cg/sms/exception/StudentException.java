package com.cg.sms.exception;

public class StudentException extends Exception
{

	public StudentException(String s) 
	{
		super(s);
		// TODO Auto-generated constructor stub
	}


	
	
	
}
