package com.cg.sms.entity;

public class Student 
{
	private long studentId;
	private String studentName;
	private String City;
	private long phoneNo;
	private String emailId;
	
	public Student() 
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public Student(int studentId, String studentName, String city, int phoneNo,
			String emailId) 
	{
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.City = city;
		this.phoneNo = phoneNo;
		this.emailId = emailId;
	}

	public long getStudentId() {
		return studentId;
	}

	public void setStudentId(long studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getCity() {
		return City;
	}

	public void setCity(String city) {
		City = city;
	}

	public long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}	
}
