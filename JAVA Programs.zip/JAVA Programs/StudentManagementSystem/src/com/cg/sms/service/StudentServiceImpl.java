package com.cg.sms.service;

import com.cg.sms.doa.StudentDAO;
import com.cg.sms.doa.StudentDAOImpl;
import com.cg.sms.entity.Student;
import com.cg.sms.exception.StudentException;

public class StudentServiceImpl implements StudentService
{
StudentDAO studentdao = new StudentDAOImpl();

	@Override
	public void AddStudent(Student student) throws StudentException {
		// TODO Auto-generated method stub
		studentdao.AddStudent(student);
	}

	@Override
	public void ViewDetails(Student student) throws StudentException {
		// TODO Auto-generated method stub
		studentdao.ViewDetails(student);
	}

	
}
