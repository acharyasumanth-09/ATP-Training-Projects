package com.cg.sms.service;

import com.cg.sms.doa.StudentDAO;
import com.cg.sms.entity.Student;
import com.cg.sms.exception.StudentException;

public interface StudentService 
{
	
	abstract void AddStudent(Student student) throws StudentException;
	abstract void ViewDetails(Student student) throws StudentException; 
}
