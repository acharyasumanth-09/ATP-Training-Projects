package com.cg.sms.doa;

import com.cg.sms.entity.Student;
import com.cg.sms.exception.StudentException;

public interface StudentDAO
{
	abstract void AddStudent(Student student) throws StudentException;
	abstract void ViewDetails(Student student1) throws StudentException; 
}
