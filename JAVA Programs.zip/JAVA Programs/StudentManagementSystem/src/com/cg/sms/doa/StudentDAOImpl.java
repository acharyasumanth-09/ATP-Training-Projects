package com.cg.sms.doa;

import com.cg.sms.entity.Student;
import com.cg.sms.exception.StudentException;

public class StudentDAOImpl implements StudentDAO 
{
 Student student1;
	@Override
	public void AddStudent(Student student) throws StudentException 
	{
		student1 = student;
		//System.out.println(" Student Name : "+student.getStudentName()+"\n Student ID : "+student.getStudentId()+"\n City : "+student.getCity()+"\n Phone Number : "+student.getPhoneNo()+"\n Email ID : "+student.getEmailId());
		// TODO Auto-generated method stub
		
	}

	@Override
	public void ViewDetails(Student student1) throws StudentException 
	{
		// TODO Auto-generated method stub
		System.out.println(" Student Details are : ");
		System.out.println("____________________________________________");
		System.out.println(" Student Name : "+student1.getStudentName()+"\n Student ID : "+student1.getStudentId()+"\n City : "+student1.getCity()+"\n Phone Number : "+student1.getPhoneNo()+"\n Email ID : "+student1.getEmailId());
		
	}
}
