/*package com.cg.eis.pl;

import com.cg.eis.bean.Employee;

public class PL 
{
	public static void main(String[] args) 
	{
		Employee employee = new Employee();
	}
}*/
