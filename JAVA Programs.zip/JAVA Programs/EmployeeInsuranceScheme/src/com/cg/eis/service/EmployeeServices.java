package com.cg.eis.service;

public interface EmployeeServices 
{
	abstract void getEmpDetails();
	abstract void viewEmpDetails();
}
