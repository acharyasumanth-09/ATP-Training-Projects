/*package com.cg.eis.service;

import com.cg.eis.bean.Employee;

public class EmployeeServiceImpl implements EmployeeServices
{
	Employee employee = new Employee();
	@Override
	public void getEmpDetails() 
	{
		// TODO Auto-generated method stub
		employee.getEmpDetails();
	}

	@Override
	public void viewEmpDetails() 
	{
		// TODO Auto-generated method stub
		employee.viewEmpDetails();
	}
	
}*/
