/*package com.cg.eis.bean;

public class Employee 
{
	private long employeeID;
	private String employeeName;
	private double salary;
	private String designation;
	private String insuranceScheme;
	
	public long getEmployeeID() 
	{
		return employeeID;
	}
	public void setEmployeeID(long employeeID) 
	{
		this.employeeID = employeeID;
	}
	public String getEmployeeName() 
	{
		return employeeName;
	}
	public void setEmployeeName(String employeeName) 
	{
		this.employeeName = employeeName;
	}
	public double getSalary() 
	{
		return salary;
	}
	public void setSalary(double salary) 
	{
		this.salary = salary;
	}
	public String getDesignation() 
	{
		return designation;
	}
	public void setDesignation(String designation) 
	{
		this.designation = designation;
	}
	public String getInsuranceScheme() 
	{
		return insuranceScheme;
	}
	public void setInsuranceScheme(String insuranceScheme) 
	{
		this.insuranceScheme = insuranceScheme;
	}
	
	public void getEmpDetails() 
	{
		// TODO Auto-generated method stub
		System.out.println("Employee ID : "+employee.getEmployeeID()+"\n Employee Name : "+employee.getEmployeeName()+"\n Salary : "+employee.getSalary()+"\n Designation : "+employee.getDesignation()+"\n Insurance Scheme: "+employee.getInsuranceScheme());
	}
	public void viewEmpDetails() 
	{
		// TODO Auto-generated method stub
		
	}
}*/
