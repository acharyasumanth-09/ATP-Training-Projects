package com.cg.bms.model;

import java.util.Date;

public class Account {
	private long accountNo;
	private String accountType;
	private String customerName;
	private double balance;
	private Date openingDate;

	public Account() {
		// TODO Auto-generated constructor stub
	}

	public long getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public Date getOpeningDate() {
		return openingDate;
	}

	public void setOpeningDate(Date openingDate) {
		this.openingDate = openingDate;
	}

	public Account(long accountNo, String accountType, String customerName,
			double balance, Date openingDate) {
		super();
		this.accountNo = accountNo;
		this.accountType = accountType;
		this.customerName = customerName;
		this.balance = balance;
		this.openingDate = openingDate;
	}

	public Account(String accountType, String customerName, double balance,
			Date openingDate) {
		super();
		this.accountType = accountType;
		this.customerName = customerName;
		this.balance = balance;
		this.openingDate = openingDate;
	}

}
