package com.cg.bms.presentation;

import java.util.Date;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.bms.exceptions.BMSException;
import com.cg.bms.model.Account;
import com.cg.bms.service.IAccountService;
import com.cg.bms.service.IAccountServiceImpl;

public class BMSMain {

	static Logger logger = Logger.getLogger(BMSMain.class);
	static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {

		IAccountService service = new IAccountServiceImpl();

		PropertyConfigurator.configure("resources/log4j.properties");
		logger.info("log4j configured");

		System.out.println("--------------------------------------------");
		System.out.println("---------Welcome to Bangalore Bank----------");
		System.out.println("--------------------------------------------");
		
		boolean x = true;
		do{
		System.out.println("\n");
		System.out.println("1. Create Account");
		System.out.println("2. Get Account Information using ID");
		System.out.println("3. Delete an account using ID");
		System.out.println("4. Update Balance of an Account using ID");
		System.out.println("5. View All the Account Details");
		System.out.println("6. Exit");
		System.out.println("--------------------------------------------");

		System.out.println("Select your Choice");
		int option = 0;

		try {
			option = scanner.nextInt();
			System.out.println("--------------------------------------------");
			logger.info("Selected option is : " + option);
		} catch (InputMismatchException e) {
			System.err.println("Enter digits only (1-6)");
			logger.error("User entered the invalid option");
			System.exit(0);
		}

		switch (option) {
		case 1:
			Account account = openAccount();
			logger.debug("Data in the Account Class is : " + account);
			try {
				boolean result = service.validateAccount(account);
				logger.debug("Validation of account is " + result);

				if (result) {
					boolean resultFlag = service.createAccount(account);
					if (resultFlag) {
						int id = service.getMaxId();
						System.out.println("Acount Created with Account Number "+id);
					} else {
						System.out.println("Account Not Created");
					}
				}
			} catch (BMSException e) {
				System.err.println(e.getMessage());
			}
			break;
		case 2:
			System.out.println("Enter accountNo for which you need to get the details :");
			long accountNum = scanner.nextLong();
			
			try {
				boolean result = service.validateID(accountNum);
				if(result){
						service.selectAccount(accountNum);	
				}else{
					System.out.println("Invalid Account Number. Account Number should be 10 Digits only..");
				}
			}catch (BMSException e) {
					System.err.println(e.getMessage());
			}
			break;
		case 3:
		
				System.out.println("Enter accountNo to delete :");
				long accountNo = scanner.nextLong();
				try {
					boolean result = service.validateID(accountNo);
					if(result){
						long res = service.deleteAccount(accountNo);	
						if(res > 0){
							System.out.println(res + " record deleted with accountNo : " + accountNo);
						}else{
							System.out.println("Invalid Account Number. Account Number doesn't exist in the DataBase");
						}
					}else{
						System.out.println("Invalid Account Number. Account Number should be 10 Digits only..");
					}
				}catch (BMSException e) {
						System.err.println(e.getMessage());
				}
			break;
			
		case 4:			
		
		System.out.println("Enter accountNo :");
		int accountNo1 = scanner.nextInt();
		scanner.nextLine();
		try {
			boolean result = service.validateID(accountNo1);
			if(result){
					System.out.println("Enter balance to update :");
					double balance = scanner.nextDouble();
					Account account1 = new Account();
					account1.setAccountNo(accountNo1);;
					account1.setBalance(balance);
					int result1 = service.updateAccount(account1);
					System.out.println(result1 + " account updated with accountNo : " + accountNo1);	
			}else{
				System.out.println("Invalid Account Number. Account Number should be 10 Digits only..");
			}
		}catch (BMSException e) {
				System.err.println(e.getMessage());
		}
		break;
			
		case 5:
			try {
				List<Account> list = service.getAllAccount();

				for (Account account2 : list) {
					System.out.println(account2.getAccountNo() + " : " + account2.getCustomerName() + " : " + account2.getAccountType() + " : "
							+ account2.getBalance() + " : " + account2.getOpeningDate());
				}

			} catch (BMSException e) {
					System.err.println(e.getMessage());
			}

			break;
		case 6:
			System.out.println("....Closing Application....");
			System.out.println("Thank You For Using Bangalore Bank");
			System.exit(0);
			break;
		default:
			System.out.println("Invalid Choice");
			logger.info("Invalid Option Selected");
			break;
	}
		}while(x=true);
}

	public static Account openAccount() {
		scanner.nextLine();
		System.out.println("Enter the Type of Account you want to Create");
		String accountType = scanner.nextLine();
		System.out.println("Enter the Customer Name");
		String customerName = scanner.nextLine();
		System.out.println("Enter Minimum Deposite Amount");
		double amount = 0;

		try {
			amount = scanner.nextDouble();
			System.out.println("--------------------------------------------");
		} catch (InputMismatchException e) {
			System.err.println("Given Input is not correct, Please Try Again");
			logger.error("The Input entered for the amount is not correct");
			System.exit(0);
		}

		Date date = new Date();

		Account account = new Account(accountType, customerName, amount, date);
		logger.info("Account Object " + account + " Created Successfully");
		return account;
	}

}
