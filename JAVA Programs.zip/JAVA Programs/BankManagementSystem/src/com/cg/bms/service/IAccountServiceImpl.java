package com.cg.bms.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.cg.bms.dao.IAccountDao;
import com.cg.bms.dao.IAccountDaoImpl;
import com.cg.bms.exceptions.BMSException;
import com.cg.bms.model.Account;

public class IAccountServiceImpl implements IAccountService {
	static Logger logger = Logger.getLogger(IAccountServiceImpl.class);
	IAccountDao accountDao = new IAccountDaoImpl();

	/*
	 * methodName - createAccount 
	 * arguments - Account object 
	 * return type - boolean 
	 * Author - Capgemini 
	 * creationDate - 12/10/2018 
	 * description - this method is used to insert the account data into the database
	 * 
	 */

	@Override
	public boolean createAccount(Account account) throws BMSException {
		logger.info("in Account Service class");
		return accountDao.createAccount(account);
	}

	@Override
	public boolean validateAccount(Account account) throws BMSException {
		boolean flag = false;
		List<String> list = new ArrayList<>();
		if (!isNameValid(account.getCustomerName())) {
			list.add("\n Customer Name should contain minimum 5 characters and maximum 20 characters.");
		}

		if (!isBalanceValid(account.getBalance())) {
			list.add("\n Account Balance should be greater then or equal to 10000");
		}

		if (!isDateValid(account.getOpeningDate())) {
			list.add("\n Date should be in yyyy-MM-dd format only.");
		}

		if (!list.isEmpty()) {
			logger.debug("List is not empty");
			throw new BMSException(list + "");
		} else {
			logger.debug("List is empty");
			flag = true;
		}
		logger.debug("Result from Validation Method is : ");
		return flag;
	}


	public boolean isNameValid(String name) {
		logger.info("In Name Validation Method");
		String nameRegEx = "[A-Za-z]{5,20}";
		Pattern pattern = Pattern.compile(nameRegEx);
		Matcher matcher = pattern.matcher(name);
		logger.debug("Name Validation : " + matcher.matches());
		return matcher.matches();
	}

	public boolean isBalanceValid(double balance) {
		logger.info("In Balance Validation Method");
		boolean balanceFlag = false;
		if (balance >= 10000) {
			balanceFlag = true;
		}
		logger.debug("Balance Validation : ");
		return balanceFlag;
	}

	public boolean isDateValid(Date date) {
		logger.info("In date Validation Method");

		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String newDate = format.format(date);

		String dateRegEx = "[0-9]{4}-[0-9]{2}-[0-9]{2}";
		Pattern pattern = Pattern.compile(dateRegEx);
		Matcher matcher = pattern.matcher(newDate);
		logger.debug("Date Validation : " + matcher.matches());
		return matcher.matches();
	}

	@Override
	public int getMaxId() throws BMSException {
		return accountDao.getMaxId();
	}

	@Override
	public long deleteAccount(long id) throws BMSException {
		return accountDao.deleteAccount(id);
	}

	@Override
	public boolean validateID(long accountNo) throws BMSException {
			logger.info("In Account Number Validation Method");
			String IdRegEx = "[0-9]{10}";
			Pattern pattern = Pattern.compile(IdRegEx);
			String accNum = accountNo+"";
			Matcher matcher = pattern.matcher(accNum);
			logger.debug("Account Number Validation : " + matcher.matches());
			return matcher.matches();
	}

	@Override
	public long selectAccount(long accountNo) throws BMSException {
		return accountDao.selectAccount(accountNo);
	}

	@Override
	public int updateAccount(Account account1) throws BMSException {
		int result1 = accountDao.updateAccount(account1);
		return result1;
	}

	@Override
	public List<Account> getAllAccount() throws BMSException {
		List<Account> list = accountDao.getAllAccounts();
		return list;
	}
}
