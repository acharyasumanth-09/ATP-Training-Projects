package com.cg.bms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.bms.exceptions.BMSException;
import com.cg.bms.model.Account;
import com.cg.bms.utility.jdbcUtility;

public class IAccountDaoImpl implements IAccountDao {
	static Logger logger = Logger.getLogger(IAccountDaoImpl.class);
	Connection connection = null;
	PreparedStatement statement = null;

	/*
	 * methodName - createAccount 
	 * arguments - Account object 
	 * return type - boolean 
	 * Author - Capgemini 
	 * creationDate - 12/10/2018 
	 * description - this method is used to insert the account data into the database
	 * 
	 */

	@Override
	public boolean createAccount(Account account) throws BMSException {
		boolean flag = false;
		connection = jdbcUtility.getConnection();
		logger.info("Connection Established");

		try {
			statement = connection
					.prepareStatement(QueryConstants.insertAccount);
			logger.debug("Statement created");
			statement.setString(1, account.getAccountType());
			statement.setString(2, account.getCustomerName());
			statement.setDouble(3, account.getBalance());

			Date date = new Date(account.getOpeningDate().getTime());
			statement.setDate(4, date);

			int result = statement.executeUpdate();

			if (result > 0) {
				logger.debug("Account Created");
				flag = true;
			}

		} catch (SQLException e) {
			logger.error("Statement object not created");
			throw new BMSException("Statement not created due to some problem");
		}finally{
			jdbcUtility.closeConnection();
		}
		return flag;
	}

	@Override
	public int getMaxId() throws BMSException {
		int id = 0;
		ResultSet resultSet = null;
		connection = jdbcUtility.getConnection();
		try {
			statement = connection.prepareStatement(QueryConstants.selectMaxId);
			resultSet = statement.executeQuery();
			
			resultSet.next();
			id = resultSet.getInt(1);
		} catch (SQLException e) {
			throw new BMSException("Unable to create statement");
		}finally{
			try {
				resultSet.close();
			} catch (SQLException e) {
				throw new BMSException("Problem while closing resultSet");
			}
			try {
				statement.close();
			} catch (SQLException e) {
				throw new BMSException("Problem while closing statement");
			}
			jdbcUtility.closeConnection();
		}			
		return id;
	}

	@Override
	public long deleteAccount(long id) throws BMSException {
		connection = jdbcUtility.getConnection();
		long res = 0;
		try{
			statement = connection.prepareStatement(QueryConstants.selectAccount);
			statement.setLong(1, id);
			ResultSet rs = statement.executeQuery();
			while(rs.next()){
				long accountNo = rs.getLong("account_no");
				String accountType = rs.getString("account_type");
				String customerName = rs.getString("customer_name");
				double balance = rs.getDouble("balance");
				Date openingDate = rs.getDate("acc_creation_date");
				
				System.out.println("----------------------------------------------------------------");
				System.out.println("The details of the customer having accountNo "+accountNo+" is");
				System.out.println("----------------------------------------------------------------");
				System.out.println("Account Number                 :- "+accountNo);
				System.out.println("Account Holder's Name          :- "+customerName);
				System.out.println("Account Type                   :- "+accountType);
				System.out.println("Balance Amount                 :- "+balance);
				System.out.println("Account Opening Date           :- "+openingDate);
				System.out.println("----------------------------------------------------------------");
				System.out.println("\n");
			}
			rs.close();
			statement = connection.prepareStatement(QueryConstants.deleteAccount);
			statement.setLong(1, id);
			res=statement.executeUpdate();
		} catch (SQLException e) {
			throw new BMSException("Unable to create statement");
		}finally{
			try {
				statement.close();
			} catch (SQLException e) {
				throw new BMSException("Problem while closing statement");
			}
			jdbcUtility.closeConnection();
		}	
		return res;
		
	}

	@Override
	public long selectAccount(long accountNo) throws BMSException {
		connection = jdbcUtility.getConnection();
		long res1 = 0;
		try{
			statement = connection.prepareStatement(QueryConstants.selectAccount);
			statement.setLong(1, accountNo);
			ResultSet rs1 = statement.executeQuery();
			while(rs1.next()){
				long accountNum = rs1.getLong("account_no");
				String accountType = rs1.getString("account_type");
				String customerName = rs1.getString("customer_name");
				double balance = rs1.getDouble("balance");
				Date openingDate = rs1.getDate("acc_creation_date");
				
				System.out.println("----------------------------------------------------------------");
				System.out.println("The details of the customer having accountNo "+accountNum+" is");
				System.out.println("----------------------------------------------------------------");
				System.out.println("Account Number                 :- "+accountNum);
				System.out.println("Account Holder's Name          :- "+customerName);
				System.out.println("Account Type                   :- "+accountType);
				System.out.println("Balance Amount                 :- "+balance);
				System.out.println("Account Opening Date           :- "+openingDate);
				System.out.println("----------------------------------------------------------------");
				System.out.println("\n");
			}
			rs1.close();
		} catch (SQLException e) {
			throw new BMSException("Unable to create statement");
		}finally{
			try {
				statement.close();
			} catch (SQLException e) {
				throw new BMSException("Problem while closing statement");
			}
			jdbcUtility.closeConnection();
		}	
		return res1;
	}

	@Override
	public int updateAccount(Account account1) throws BMSException {
		connection = jdbcUtility.getConnection();
		int res2 = 0;
		try{
			statement = connection.prepareStatement(QueryConstants.updateAccount);
			statement.setDouble(1, account1.getBalance());
			statement.setLong(2, account1.getAccountNo());

			res2 = statement.executeUpdate();
		}catch (SQLException e) {
			throw new BMSException("Unable to create statement");
		}finally{
			try {
				statement.close();
			}catch (SQLException e) {
				throw new BMSException("Problem while closing statement");
			}
			jdbcUtility.closeConnection();
		}	
		return res2;
	}

	@Override
	public List<Account> getAllAccounts() throws BMSException {

		List<Account> list = new ArrayList<Account>();

		connection = jdbcUtility.getConnection();
		try{
			statement = connection.prepareStatement(QueryConstants.selectAllAccount);

			ResultSet resultSet = statement.executeQuery();

			while (resultSet.next()) {

			long accountNo = resultSet.getLong(1);
			String customerName = resultSet.getString(2);
			String accountType = resultSet.getString(3);
			double balance = resultSet.getDouble(4);
			Date openingDate = resultSet.getDate(5);

			Account account = new Account(accountNo, customerName, accountType, balance, openingDate);
			list.add(account);
			}
		}catch (SQLException e) {
			throw new BMSException("Unable to create statement");
		}finally{
			try {
				statement.close();
			}catch (SQLException e) {
				throw new BMSException("Problem while closing statement");
			}
			jdbcUtility.closeConnection();
		}
		return list;
	}	
}
