package com.cg.bms.dao;

public interface QueryConstants {
	public static final String insertAccount = "insert into account_master values(account_sequence.nextval,?,?,?,?)";
	
	public static final String selectMaxId = "select max(account_no) from account_master";
	
	public static final String deleteAccount = "delete from account_master where account_no=?";
	
	public static final String selectAccount = "select account_no,account_type,customer_name,balance,acc_creation_date from account_master where account_no = ?";

	public static final String updateAccount = "update account_master set balance=? where account_no=?";

	public static final String selectAllAccount = "select * from account_master";
}
