package com.cg.bms.dao;

import java.util.List;

import com.cg.bms.exceptions.BMSException;
import com.cg.bms.model.Account;

public interface IAccountDao {

	boolean createAccount(Account account) throws BMSException;
	
	public long deleteAccount(long id) throws BMSException;
	
	public int getMaxId() throws BMSException;

	long selectAccount(long accountNo)throws BMSException;

	int updateAccount(Account account1)throws BMSException;

	List<Account> getAllAccounts() throws BMSException;
}
