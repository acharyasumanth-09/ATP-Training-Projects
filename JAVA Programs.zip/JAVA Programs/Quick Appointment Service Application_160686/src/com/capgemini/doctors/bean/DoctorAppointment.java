package com.capgemini.doctors.bean;

import java.util.Date;

public class DoctorAppointment {

	private int appointmentId;
	private String patientName;
	private String phoneNumber;
	private Date date;
	private String mailId;
	private int age;
	private String gender;
	private String problemName;
	private String doctorName;
	private String appointmentStatus = "DISAPPROVED";

	public DoctorAppointment() {

	}

	public DoctorAppointment(int appointmentId, String patientName,
			String phoneNumber, Date date, String mailId, int age,
			String gender, String problemName, String doctorName,
			String appointmentStatus) {
		super();
		this.appointmentId = appointmentId;
		this.patientName = patientName;
		this.phoneNumber = phoneNumber;
		this.date = date;
		this.mailId = mailId;
		this.age = age;
		this.gender = gender;
		this.problemName = problemName;
		this.doctorName = doctorName;
		this.appointmentStatus = appointmentStatus;
	}

	public int getAppointmentId() {
		return appointmentId;
	}

	public void setAppointmentId(int appointmentId) {
		this.appointmentId = appointmentId;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public DoctorAppointment(String patientName, String phoneNumber, Date date,
			String mailId, int age, String gender, String problemName,
			String appointmentStatus) {
		super();
		this.patientName = patientName;
		this.phoneNumber = phoneNumber;
		this.date = date;
		this.mailId = mailId;
		this.age = age;
		this.gender = gender;
		this.problemName = problemName;
		this.appointmentStatus = appointmentStatus;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getMailId() {
		return mailId;
	}

	public void setMailId(String mailId) {
		this.mailId = mailId;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getProblemName() {
		return problemName;
	}

	public void setProblemName(String problemName) {
		this.problemName = problemName;
	}

	public String getDoctorName() {
		return doctorName;
	}

	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}

	public String getAppointmentStatus() {
		return appointmentStatus;
	}

	public void setAppointmentStatus(String appointmentStatus) {
		this.appointmentStatus = appointmentStatus;
	}

	public DoctorAppointment(String patientName, String phoneNumber, Date date,
			String mailId, int age, String gender, String problemName,
			String doctorName, String appointmentStatus) {
		super();
		this.patientName = patientName;
		this.phoneNumber = phoneNumber;
		this.date = date;
		this.mailId = mailId;
		this.age = age;
		this.gender = gender;
		this.problemName = problemName;
		this.doctorName = doctorName;
		this.appointmentStatus = appointmentStatus;
	}

}
