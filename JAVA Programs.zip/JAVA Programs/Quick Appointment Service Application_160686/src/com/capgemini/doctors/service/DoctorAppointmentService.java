package com.capgemini.doctors.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDao;
import com.capgemini.doctors.dao.IDoctorAppointmentDao;
import com.capgemini.doctors.exception.DoctorsException;

public class DoctorAppointmentService implements IDoctorAppointmentService {

	IDoctorAppointmentDao doctorAppointmentDao = new DoctorAppointmentDao();

	/*
	 * methodName	 - getAppointment
	 * arguments	 - DoctorApointment object return type- boolean
	 * Author		 - capgemini 
	 * creationDate	 -16/10/2018 
	 * this method passes control to Dao getAppointment method.
	 */
	
	@Override
	public boolean getAppointment(DoctorAppointment doctorAppointment,
			String result) throws DoctorsException {

		return doctorAppointmentDao.getAppointment(doctorAppointment, result);
	}

	/*
	 * methodName	 - getDoctoName
	 * arguments	 - DoctorApointment object return type- boolean
	 * Author		 - capgemini 
	 * creationDate	 -16/10/2018 
	 *this method passes control to Dao getDoctoName method.
	 */
	
	@Override
	public String getDoctoName(DoctorAppointment doctorAppointment)
			throws DoctorsException {

		return doctorAppointmentDao.getDoctoName(doctorAppointment);
	}
	/*
	 * methodName	 - getAppointment
	 * arguments	 - DoctorApointment object return type- boolean
	 * Author		 - capgemini 
	 * creationDate	 -16/10/2018 
	 * this method passes control to Dao getAppointmentId method.
	 */
	@Override
	public int getAppointmentId() throws DoctorsException {

		return doctorAppointmentDao.getAppointmentId();
	}
	
	/*
	 * methodName	 - validateDetails
	 * arguments	 - DoctorApointment object return type- boolean
	 * Author		 - capgemini 
	 * creationDate	 -16/10/2018 
	 * this method is used to validate the details.
	 */
	
	
	@Override
	public boolean validateDetails(DoctorAppointment doctorAppointment)
			throws DoctorsException {

		boolean flag = false;
		List<String> list = new ArrayList<String>();

		if (!isNameValid(doctorAppointment.getPatientName())) {
			list.add("name is invalid");
		}
		if (!isPhoneValid(doctorAppointment.getPhoneNumber())) {
			list.add("phone number is invalid");
		}
		if (!isAgeValid(doctorAppointment.getAge())) {
			list.add("age is invalid");
		}
		if (!isGenderValid(doctorAppointment.getGender())) {
			list.add("Gender is invalid");
		}
		if (list.isEmpty()) {
			flag = true;
		} else
			throw new DoctorsException(list + "");
		return flag;
	}
	/*
	 * methodName	 - isGenderValid
	 * arguments	 - String literal return type- boolean
	 * Author		 - capgemini 
	 * creationDate	 -16/10/2018 
	 * this method is used to check the pattern of given String literal.
	 */
	
	private boolean isGenderValid(String gender) {
		String regExPattern = "[A-Za-z]{4,6}";
		Pattern pattern = Pattern.compile(regExPattern);
		Matcher matcher = pattern.matcher(gender);

		return matcher.matches();
	}
	/*
	 * methodName	 - isAgeValid
	 * arguments	 - String literal return type- boolean
	 * Author		 - capgemini 
	 * creationDate	 -16/10/2018 
	 * this method is used to check the pattern of given Integer literal.
	 */
	
	private boolean isAgeValid(int age) {
		String regExPattern = "[0-9]{2}";
		String newAge = String.valueOf(age);
		Pattern pattern = Pattern.compile(regExPattern);
		Matcher matcher = pattern.matcher(newAge);

		return matcher.matches();
	}
	/*
	 * methodName	 - isPhoneValid
	 * arguments	 - String literal return type- boolean
	 * Author		 - capgemini 
	 * creationDate	 -16/10/2018 
	 * this method is used to check the pattern of given String literal.
	 */
	
	private boolean isPhoneValid(String phoneNumber) {

		String regExPattern = "[0-9]{10}";
		Pattern pattern = Pattern.compile(regExPattern);
		Matcher matcher = pattern.matcher(phoneNumber);

		return matcher.matches();
	}
	
	/*
	 * methodName	 - isNameValid
	 * arguments	 - String literal return type- boolean
	 * Author		 - capgemini 
	 * creationDate	 -16/10/2018 
	 * this method is used to check the pattern of given String literal.
	 */
	
	private boolean isNameValid(String patientName) {

		String regExPattern = "[A-Za-z]{5,20}";
		Pattern pattern = Pattern.compile(regExPattern);
		Matcher matcher = pattern.matcher(patientName);

		return matcher.matches();
	}

	/*
	 * methodName	 - updateAppointmentStatus
	 * arguments	 - String literal return type- boolean
	 * Author		 - capgemini 
	 * creationDate	 -16/10/2018 
	 * this method is used to update the appointment status in the database
	 */
	@Override
	public boolean updateAppoinmentStatus(String patientName) throws DoctorsException {
		
		return doctorAppointmentDao.updateAppointmentStatus(patientName);
	}

}
