package com.capgemini.doctors.service;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exception.DoctorsException;

public interface IDoctorAppointmentService {

	boolean getAppointment(DoctorAppointment doctorAppointment, String result)throws DoctorsException;

	String getDoctoName(DoctorAppointment doctorAppointment) throws DoctorsException;

	int getAppointmentId() throws DoctorsException;

	boolean validateDetails(DoctorAppointment doctorAppointment) throws DoctorsException;

	boolean updateAppoinmentStatus(String patientName) throws DoctorsException;

}
