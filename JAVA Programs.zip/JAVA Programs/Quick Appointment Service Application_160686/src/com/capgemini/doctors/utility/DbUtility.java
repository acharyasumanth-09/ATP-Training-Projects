package com.capgemini.doctors.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.capgemini.doctors.exception.DoctorsException;

public class DbUtility {

	static Connection connection = null;

	public static Connection getConnection() throws DoctorsException {

		Properties properties = new Properties();
		try {
			properties.load(new FileInputStream(new File(
					"resources/jdbc.properties")));
			String driver = properties.getProperty("db.driver");
			String url = properties.getProperty("db.url");
			String username = properties.getProperty("db.username");
			String password = properties.getProperty("db.password");

			Class.forName(driver);
			connection = DriverManager.getConnection(url, username, password);

		} catch (FileNotFoundException e) {
			throw new DoctorsException("check the path of properties file");
		} catch (IOException e) {
			throw new DoctorsException("check the jdbc properties file");
		} catch (ClassNotFoundException e) {
			throw new DoctorsException("unable to load class");
		} catch (SQLException e) {
			throw new DoctorsException("unable to create the connection");
		}
		return connection;

	}
}
