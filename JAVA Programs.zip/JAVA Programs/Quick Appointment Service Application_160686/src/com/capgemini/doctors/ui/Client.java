package com.capgemini.doctors.ui;

import java.util.Date;
import java.util.Scanner;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exception.DoctorsException;
import com.capgemini.doctors.service.DoctorAppointmentService;
import com.capgemini.doctors.service.IDoctorAppointmentService;

public class Client {

	@SuppressWarnings("resource")
	public static void main(String[] args) throws DoctorsException {

		IDoctorAppointmentService appointmentService = new DoctorAppointmentService();
		Scanner scanner = new Scanner(System.in);

		System.out.println("----Welcome to GoodHealth Appointment Service----");
		System.out.println("Menu");
		System.out.println("1) Book Doctor Appointment");
		System.out.println("2) Exit");
		System.out.println("Enter choice");
		int input = scanner.nextInt();
		switch (input) {
		case 1:
			System.out.println("Please enter details");
			scanner.nextLine();
			System.out.println("Enter Name of the Patient");
			String patientName = scanner.nextLine();
			System.out.println("Enter Phone Number");
			String phoneNumber = scanner.nextLine();
			System.out.println("Enter Email");
			String mailId = scanner.nextLine();
			System.out.println("Enter Age");
			int age = scanner.nextInt();
			scanner.nextLine();
			System.out.println("Enter Gender");
			String gender = scanner.nextLine();
			System.out.println("Enter Problem Name");
			String problemName = scanner.nextLine();
			String appointmentStatus = "DISAPPROVED";

			Date date = new Date();
			DoctorAppointment doctorAppointment = new DoctorAppointment(
					patientName, phoneNumber, date, mailId, age, gender,
					problemName, appointmentStatus);

			String result = null;
			try {
				boolean validationResult = appointmentService
						.validateDetails(doctorAppointment);
				if (validationResult) {

					result = appointmentService.getDoctoName(doctorAppointment);
					boolean insertedResult = appointmentService.getAppointment(
							doctorAppointment, result);
					if (insertedResult) {
						int res = appointmentService.getAppointmentId();
						boolean updatedResult=appointmentService.updateAppoinmentStatus(patientName);
						if(updatedResult)
						System.out
								.println("Your Doctor Appointment has been successfully generated, your appointment id is "
										+ res);
					}
				}
			} catch (DoctorsException e) {
				throw new DoctorsException(e.getMessage());
			}
			break;

		case 2:
			System.exit(0);

		default:
			scanner.close();
			break;
		}

	}

}
