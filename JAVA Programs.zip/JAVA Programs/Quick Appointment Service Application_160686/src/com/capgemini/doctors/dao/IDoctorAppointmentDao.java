package com.capgemini.doctors.dao;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exception.DoctorsException;

public interface IDoctorAppointmentDao {

	boolean getAppointment(DoctorAppointment doctorAppointment, String result) throws DoctorsException;
	String getDoctoName(DoctorAppointment doctorAppointment) throws DoctorsException;
	int getAppointmentId() throws DoctorsException;
	boolean updateAppointmentStatus(String patientName) throws DoctorsException;

}
