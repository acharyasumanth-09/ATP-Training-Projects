package com.capgemini.doctors.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exception.DoctorsException;
import com.capgemini.doctors.utility.DbUtility;

public class DoctorAppointmentDao implements IDoctorAppointmentDao {
	
	static Logger logger = Logger.getLogger(IDoctorAppointmentDao.class);
	Connection connection = null;
	PreparedStatement preparedStatement = null;
	
	/*
	 * methodName	 - getAppointment
	 * arguments	 - DoctorApointment object return type- boolean
	 * Author		 - capgemini 
	 * creationDate	 -16/10/2018 
	 * this method is used to insert in the database.
	 */
	@Override
	public boolean getAppointment(DoctorAppointment doctorAppointment,
			String result) throws DoctorsException {

		int res = 0;
		boolean flag = false;
		try {
			connection = DbUtility.getConnection();
			logger.info("connection established.");
			preparedStatement = connection
					.prepareStatement(QueryConstants.insertQuery);
			logger.info("prepareStatement created.");
			preparedStatement.setString(1, doctorAppointment.getPatientName());
			preparedStatement.setString(2, doctorAppointment.getPhoneNumber());
			preparedStatement.setString(3, doctorAppointment.getMailId());
			preparedStatement.setInt(4, doctorAppointment.getAge());
			preparedStatement.setString(5, doctorAppointment.getGender());
			preparedStatement.setString(6, doctorAppointment.getProblemName());
			preparedStatement.setString(7, result);
			preparedStatement.setString(8,
					doctorAppointment.getAppointmentStatus());
			res = preparedStatement.executeUpdate();
			if (res >= 0) {
				logger.info("executed successfully..");
				flag = true;
			}

		} catch (SQLException e) {
			logger.error("error occured");
			throw new DoctorsException("check insert query query");
		} 

		return flag;
	}
	/*
	 * methodName	 - getDoctoName
	 * arguments	 - DoctorApointment object return type- boolean
	 * Author		 - capgemini 
	 * creationDate	 -16/10/2018 
	 * this method is used to get the doctor name from the database.
	 */
	@Override
	public String getDoctoName(DoctorAppointment doctorAppointment)
			throws DoctorsException {
		String name = null;
		try {
			connection = DbUtility.getConnection();
			logger.info("connection established.");
			preparedStatement = connection
					.prepareStatement(QueryConstants.getPatientQuery);
			logger.info("prepareStatement created.");
			preparedStatement.setString(1, doctorAppointment.getProblemName());

			ResultSet resultSet = preparedStatement.executeQuery();
			resultSet.next();
			name = resultSet.getString(1);
			logger.info("executed successfully");
			
			

		} catch (SQLException e) {
			logger.error("error occured");
			throw new DoctorsException("check patient query");
		}

		return name;
	}
	/*
	 * methodName	 - getAppointmentId
	 * arguments	 - DoctorApointment object return type- boolean
	 * Author		 - capgemini 
	 * creationDate	 -16/10/2018 
	 * this method is used to get appointment id from the database.
	 */
	@Override
	public int getAppointmentId() throws DoctorsException {

		int id = 0;

		try {
			connection = DbUtility.getConnection();
			logger.info("connection established.");
			preparedStatement = connection
					.prepareStatement(QueryConstants.getPatientIdQuery);
			logger.info("prepareStatement created.");

			ResultSet resultSet = preparedStatement.executeQuery();
			resultSet.next();
			id = resultSet.getInt(1);
			logger.info("executed successfully.");

		} catch (SQLException e) {
			logger.error("error occured.");
			throw new DoctorsException("check appointment id query");
		}
		return id;
	}
	/*
	 * methodName	 - updateAppointmentStatus
	 * arguments	 - DoctorApointment object return type- boolean
	 * Author		 - capgemini 
	 * creationDate	 -16/10/2018 
	 * this method is used to update the appointment status in the database.
	 */
	@Override
	public boolean updateAppointmentStatus(String patientName) throws DoctorsException {
		
		boolean flag = false;
		int res=0;
			
		try {
			connection = DbUtility.getConnection();
			logger.info("connection established.");
			preparedStatement = connection
					.prepareStatement(QueryConstants.updateAppointmentStatusQuery);
			logger.info("prepareStatement created.");
			preparedStatement.setString(1, "APPROVED");
			preparedStatement.setString(2, patientName);
			res=preparedStatement.executeUpdate();
			if(res>=0){
				logger.info("executed successfully.");
				flag = true;
			}
		} catch (SQLException e) {
			logger.info("error occured.");
			throw new DoctorsException("check query again..");
		}
		
		return flag;
	}

}
