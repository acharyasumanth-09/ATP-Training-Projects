package com.capgemini.doctors.dao;

public interface QueryConstants {
	
	public static String getPatientQuery="select doctor_name from doctors where problem_name=?";
	public static String insertQuery="insert into doctor_appointment values (seq_appointment_id.nextval,?,?,sysdate+1,?,?,?,?,?,?)";
	public static String getPatientIdQuery="select max(appointment_id) from doctor_appointment";
	public static String updateAppointmentStatusQuery="update doctor_appointment set appointment_status=? where patient_name=?";

}
