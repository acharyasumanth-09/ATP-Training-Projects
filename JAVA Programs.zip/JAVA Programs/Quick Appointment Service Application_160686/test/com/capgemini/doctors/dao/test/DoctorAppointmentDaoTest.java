package com.capgemini.doctors.dao.test;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDao;
import com.capgemini.doctors.dao.IDoctorAppointmentDao;
import com.capgemini.doctors.exception.DoctorsException;

public class DoctorAppointmentDaoTest {
	
	IDoctorAppointmentDao dao=null;
	@Before
	public void setUp() throws Exception {
		dao=new DoctorAppointmentDao();
	}

	@After
	public void tearDown() throws Exception {
		dao=null;
	}

	@Test
	public void testGetAppointmentId() {
		
		DoctorAppointment doctorAppointment=new DoctorAppointment("Kumar", "9491846203", new Date(2018,10,17), "yuva@gmail.com", 25, "male", "Heart", "APPROVED");
		boolean res;
		try {
			res = dao.getAppointment(doctorAppointment, "Heart");
			assertEquals(true, res);
		} catch (DoctorsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Test
	public void testGetAppointmentId1() {
		
		DoctorAppointment doctorAppointment=new DoctorAppointment("Kumar", "9491846203", new Date(2018,10,17), "yuva@gmail.com", 25, "male", "Heart", "APPROVED");
		boolean res=false;
		try {
			res = dao.getAppointment(doctorAppointment, "Heart");
			assertFalse(false);
		} catch (DoctorsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
