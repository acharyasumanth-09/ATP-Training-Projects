package com.cg.expensemodule.dao;

import java.util.List;

import com.cg.expensemodule.bean.ExpenseModule;

public interface IExpenseDao {

	ExpenseModule createExpenseModule(ExpenseModule expense);

	List<ExpenseModule> readExpenseModule();

	ExpenseModule deleteExpenseModule(String expenseCode);

	ExpenseModule updateExpenseModule(String expenseCode,
			ExpenseModule expenseModule);

	ExpenseModule readExpenseModuleById(String expenseCode);

}
