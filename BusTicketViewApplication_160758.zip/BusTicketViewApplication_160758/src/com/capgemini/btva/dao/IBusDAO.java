package com.capgemini.btva.dao;

import java.util.List;

import com.capgemini.btva.beans.Client;

public interface IBusDAO {

	List<Client> getAllDetails();

}
