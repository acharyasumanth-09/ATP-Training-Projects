package com.capgemini.btva.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.btva.beans.Client;

@Repository
public class BusDAOImpl implements IBusDAO {

	@PersistenceContext
	EntityManager entityManager;

	@Override
	public List<Client> getAllDetails() {
		TypedQuery<Client> query = entityManager.createQuery(
				"select b from  busdetails",Client.class);
		return query.getResultList();
	}
}
