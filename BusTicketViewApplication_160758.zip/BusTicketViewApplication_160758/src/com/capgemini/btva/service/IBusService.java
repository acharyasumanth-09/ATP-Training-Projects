package com.capgemini.btva.service;

import java.util.List;

import com.capgemini.btva.beans.Client;

public interface IBusService {

	List<Client> getAllDetails();

}
