package com.capgemini.btva.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.btva.beans.Client;
import com.capgemini.btva.dao.IBusDAO;

@Service
@Transactional
public class BusServiceImpl implements IBusService {

	@Autowired
	IBusDAO dao;

	public IBusDAO getDao() {
		return dao;
	}

	public void setDao(IBusDAO dao) {
		this.dao = dao;
	}

	@Override
	public List<Client> getAllDetails() {

		return dao.getAllDetails();
	}

}
