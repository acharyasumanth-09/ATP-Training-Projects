package com.capgemini.btva.beans;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "busdetails1")
public class Client {

	@Id
	@NotEmpty
	private Integer busId;

	@NotEmpty
	//@Pattern(regexp = "[A-Z]{1}[a-z]{2,}", message = "Bus Travel Name should start with capitals only!!")
	private String busTravelName;

	@NotEmpty
	//@Pattern(regexp = "[A-Z]{1}[a-z]{2,}", message = "Source Name should start with capitals only!!")
	private String source;

	@NotEmpty
	//@Pattern(regexp = "[A-Z]{1}[a-z]{2,}", message = "Destination Name should start with capitals only!!")
	private String destination;

	@NotNull
	private Integer seatsAvailability;

	public Client() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Client(Integer busId, String busTravelName, String source,
			String destination, Integer seatsAvailability) {
		super();
		this.busId = busId;
		this.busTravelName = busTravelName;
		this.source = source;
		this.destination = destination;
		this.seatsAvailability = seatsAvailability;
	}

	public Integer getBusId() {
		return busId;
	}

	public void setBusId(Integer busId) {
		this.busId = busId;
	}

	public String getBusTravelName() {
		return busTravelName;
	}

	public void setBusTravelName(String busTravelName) {
		this.busTravelName = busTravelName;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public Integer getSeatsAvailability() {
		return seatsAvailability;
	}

	public void setSeatsAvailability(Integer seatsAvailability) {
		this.seatsAvailability = seatsAvailability;
	}
}