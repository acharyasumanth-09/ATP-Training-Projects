package com.capgemini.btva.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.btva.beans.Client;
import com.capgemini.btva.exceptions.CustomException;
import com.capgemini.btva.service.IBusService;

@Controller
public class BusController {
	
	@Autowired
	IBusService service;

	public IBusService getService() {
		return service;
	}

	public void setService(IBusService service) {
		this.service = service;
	}
	
	@RequestMapping("/showLoginPage")
	public String showLoginPage() {
		return "login";
	}
	
	@RequestMapping("/showIndexPage")
	public String showIndexPage() {
		return "index";
	}

	/*@RequestMapping("/showAllBusDetails")
	public String getAllDetails(Model model){
		List<Client> list=service.getAllDetails();
		model.addAttribute("list",list);
		return "getBusDetails";
	}*/
	
	@RequestMapping("/showAllBusDetails")
	public ModelAndView getAllDetails(@ModelAttribute("client") @Valid Client client,
			BindingResult result) throws CustomException {

		ModelAndView mv = new ModelAndView();
		try{
		List<Client> list = service.getAllDetails();
		System.out.println(list.toString());
		if (list.isEmpty()) {
			throw new CustomException();
			
		} 
			mv.setViewName("getBusDetails");
			mv.addObject("list", list);
		}catch(Exception e)
		{
			throw new CustomException("There are no Buses Available");
		}
		return mv;
	}
}
