package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.StudentDAO;
import com.cg.entity.Student;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	private StudentDAO studentDao;

	@Override
	public List<Student> getAllStudents() {
		return studentDao.getAllStudents();
	}

	@Override
	public Student getStudById(String studId) {

		return studentDao.getStudById(studId);
	}

	@Override
	public Student addNewStud(Student student) {

		return studentDao.addNewStud(student);
	}

	@Override
	public Student updateStudent(Student student) {
		return studentDao.updateStudent(student);
	}
	
	@Override
	public Object getAllUserSettings(String studId) {
		return studentDao.getAllUserSettings(studId);
	}

	@Override
	public String getUserSetting(String studId, String key) {

		return studentDao.getUserSetting(studId, key);
	}

	@Override
	public String addUserSetting(String studId, String key, String value) {

		return studentDao.addUserSetting(studId, key, value);
	}

	@Override
	public Student deleteStud(String studId) {

		return studentDao.deleteStud(studId);
	}
}
