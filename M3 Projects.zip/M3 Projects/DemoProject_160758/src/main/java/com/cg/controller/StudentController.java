package com.cg.controller;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Student;
import com.cg.exception.StudentNotFoundException;
import com.cg.service.StudentService;

@RestController
@RequestMapping(value = "/")
public class StudentController {

	private final Logger LOG = LoggerFactory.getLogger(getClass());

	
	@Autowired
	private  StudentService studentService;

	

	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public Student addNewStud(@Valid @RequestBody Student student) {
		LOG.info("Saving Student Details .");
		return studentService.addNewStud(student);
	}
	
	@RequestMapping(value = "/delete/{studId}", method = RequestMethod.DELETE)
	public Student deleteStud(@PathVariable String studId) {
		LOG.info("Deleting Student.");
		return studentService.deleteStud(studId);
	}

	@RequestMapping(value = "/read", method = RequestMethod.GET)
	public List<Student> getAllStudents() {
		LOG.info("Getting all Students.");
		return studentService.getAllStudents();
	}

	@RequestMapping(value = "/find/{studId}", method = RequestMethod.GET)
	public Student getStudent(@PathVariable String studId) {
		LOG.info("Getting Student with ID: {}.", studId);
	    Student  student = studentService.getStudById(studId);
	    if( student == null)
	    {
	    	throw new StudentNotFoundException(" Student Not Found ");
	    }
	    
	    return student;
	}
	
	@RequestMapping(value="/update/{studId}",method=RequestMethod.PUT)
	private Student updateStudent(@PathVariable String studId,@RequestBody Student student){
		student.setStudId(studId);
		return studentService.updateStudent(student);
	}
	
	@RequestMapping(value = "/settings/{studId}", method = RequestMethod.GET)
	public Object getAllUserSettings(@PathVariable String studId) {
		Student student = studentService.getStudById(studId);
		if (student != null) {
			return studentService.getAllUserSettings(studId);
		} else {
			return "Student not found.";
		}
	}

	

	@RequestMapping(value = "/settings/{studId}/{key}", method = RequestMethod.GET)
	public String getUserSetting(@PathVariable String studId, @PathVariable String key) {
		return studentService.getUserSetting(studId, key);
	}

	@RequestMapping(value = "/settings/{studId}/{key}/{value}", method = RequestMethod.PUT)
	public String addUserSetting(@PathVariable String studId, @PathVariable String key, @PathVariable String value) {
		Student student = studentService.getStudById(studId);
		if (student != null) {
			student.getUserSettings().put(key, value);
			studentService.addNewStud(student);
			return "Key added";
		} else {
			return "Student not found.";
		}
	}
}

