package com.cg.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.cg.entity.Student;

@Repository
public class StudentDAOImpl implements StudentDAO {

	@Autowired
	private MongoTemplate mongoTemplate;

	@Override
	public List<Student> getAllStudents() {
		return mongoTemplate.findAll(Student.class);
	}

	@Override
	public Student getStudById(String studId) {
		Query query = new Query();
		query.addCriteria(Criteria.where("studId").is(studId));
		return mongoTemplate.findOne(query, Student.class);
	}

	@Override
	public Student addNewStud(Student student) {
		mongoTemplate.save(student);
		// Now, user object will contain the ID as well
		return student;
	}

	@Override
	public Student updateStudent(Student student) {
		mongoTemplate.save(student);
		return student;
	}
	
	@Override
	public Object getAllUserSettings(String studId) {
		Query query = new Query();
		query.addCriteria(Criteria.where("studId").is(studId));
		Student student = mongoTemplate.findOne(query, Student.class);
		return student != null ? student.getUserSettings() : "Student not found.";
	}

	@Override
	public String getUserSetting(String studId, String key) {
		Query query = new Query();
		query.fields().include("userSettings");
		query.addCriteria(Criteria.where("studId").is(studId).andOperator(Criteria.where("userSettings." + key).exists(true)));
		Student student = mongoTemplate.findOne(query, Student.class);
		return student != null ? student.getUserSettings().get(key) : "Not found.";
	}

	@Override
	public String addUserSetting(String studId, String key, String value) {
		Query query = new Query();
		query.addCriteria(Criteria.where("studId").is(studId));
		Student student = mongoTemplate.findOne(query, Student.class);
		if (student != null) {
			student.getUserSettings().put(key, value);
			mongoTemplate.save(student);
			return "Key added.";
		} else {
			return "Student not found.";
		}
	}

	@Override
	public Student deleteStud(String studId) {
		Student student = getStudById(studId);
		if(student != null)
		{
			mongoTemplate.remove(student);
		}
		return student;
	}
}
