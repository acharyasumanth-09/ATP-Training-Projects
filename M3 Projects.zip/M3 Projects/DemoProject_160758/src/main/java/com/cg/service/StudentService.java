package com.cg.service;

import java.util.List;

import com.cg.entity.Student;

public interface StudentService {

	List<Student> getAllStudents();

	Student getStudById(String studId);

	Student addNewStud(Student student);
	
	Student  deleteStud(String studId) ;

	Student updateStudent(Student student);
	
	Object getAllUserSettings(String studId);

	String getUserSetting(String studId, String key);

	String addUserSetting(String studId, String key, String value);
}