package com.cg.entity;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;





import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonFormat;

@Document
public class Student {

	@Id
	private String studId;

	@NotNull
	@Size(min=2, message="Name should have atleast 2 characters")
	private String studname;
	
	@NotNull
	@Size(max=2, message="Age should be max 2 digits")
	private String age;
	
	@JsonFormat(shape=JsonFormat.Shape.STRING)
	private Date joiningDate = new Date();
	
	private Map<String, String> userSettings = new HashMap<>();

	public String getStudId() {
		return studId;
	}

	public void setStudId(String studId) {
		this.studId = studId;
	}

	public String getStudname() {
		return studname;
	}

	public void setStudname(String studname) {
		this.studname = studname;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public Date getJoiningDate() {
		return joiningDate;
	}

	public void setJoiningDate(Date joiningDate) {
		this.joiningDate = joiningDate;
	}

	public Map<String, String> getUserSettings() {
		return userSettings;
	}

	public void setUserSettings(Map<String, String> userSettings) {
		this.userSettings = userSettings;
	}
}