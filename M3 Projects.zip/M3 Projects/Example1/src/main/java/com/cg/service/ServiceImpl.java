package com.cg.service;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Student;
import com.cg.dao.IDao;
@Service
public class ServiceImpl implements IService {
	
	@Autowired
	IDao dao;
	@Override
	public Student addStudent(@Valid Student student) {
		
		return dao.addStudent(student);
	}
	@Override
	public Student deleteStudent(String id) {
		return dao.deleteStudent(id);
	}
	@Override
	public Student getStudentById(String id) {
		return dao.getStudentById(id);
	}
	@Override
	public List<Student> getAllStudents() {
		return dao.getAllStudents();
	}
	@Override
	public Student updateStudent(Student student) {
		return dao.updateStudent(student);
	}

}
