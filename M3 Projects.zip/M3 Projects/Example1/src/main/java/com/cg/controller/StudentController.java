package com.cg.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.Example1.exception.StudentNotFound;
import com.cg.bean.Student;
import com.cg.service.IService;

@RestController
@RequestMapping(value="/")
public class StudentController {
	@Autowired
	private IService service;
	
	@RequestMapping(value="/create",method=RequestMethod.POST)
	private Student addStudent(@Valid @RequestBody Student student)
	{
		return service.addStudent(student);
	}
	
	@RequestMapping(value="/delete/{id}", method=RequestMethod.DELETE)
	private Student deleteStudent(@PathVariable String id){
		return service.deleteStudent(id);
	}
	
	@RequestMapping(value="/read/{id}", method=RequestMethod.GET)
	private Student getStudentById(@PathVariable String id){
		Student student = service.getStudentById(id);
		if(student==null)
			throw new StudentNotFound("No student by that id");
		return service.getStudentById(id);
	}
	
	@RequestMapping(value="/readAll", method=RequestMethod.GET)
	private List<Student> getAllStudents(){
		return service.getAllStudents();
	}
	
	@RequestMapping(value="/update/{id}",method=RequestMethod.PUT)
	private Student updateStudent(@PathVariable String id,@RequestBody Student student){
		student.setId(id);
		return service.updateStudent(student);
	}
}
