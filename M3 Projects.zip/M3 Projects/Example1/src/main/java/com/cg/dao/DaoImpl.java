package com.cg.dao;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.cg.bean.Student;
@Repository
public class DaoImpl implements IDao{
	
	@Autowired
	private MongoTemplate mongo;
	@Override
	public Student addStudent(@Valid Student student) {
		mongo.save(student);
		return student;
	}
	@Override
	public Student deleteStudent(String id) {
		Student student= getStudentById(id);
		if(student!=null)
			mongo.remove(student);
		return student;
	}
	@Override
	public Student getStudentById(String id) {
		Query query = new Query();
		query.addCriteria(Criteria.where("id").is(id));
		return mongo.findOne(query, Student.class);
	}
	@Override
	public List<Student> getAllStudents() {
		
		return mongo.findAll(Student.class);
	}
	@Override
	public Student updateStudent(Student student) {
		mongo.save(student);
		return student;
	}

}
