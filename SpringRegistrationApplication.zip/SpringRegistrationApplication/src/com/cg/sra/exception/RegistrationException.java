package com.cg.sra.exception;


import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;


@ControllerAdvice
public class RegistrationException {
	@ExceptionHandler(value = { Exception.class })
	public ModelAndView handleConflict(Exception ex, HttpServletRequest req) {
		
		ModelAndView mv=new ModelAndView();
		String bodyOfResponse = ex.getMessage();
		String uri = req.getRequestURL().toString();

		ErrorInfo errorInfo = new ErrorInfo(uri, bodyOfResponse);
		mv.addObject("errorInfo", errorInfo);
		mv.setViewName("myError");
		return mv;
	}
}
