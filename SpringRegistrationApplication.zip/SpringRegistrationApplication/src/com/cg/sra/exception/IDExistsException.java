package com.cg.sra.exception;

public class IDExistsException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public IDExistsException() {
		super();
	}

	public IDExistsException(String message) {
		super(message);
	}
}
