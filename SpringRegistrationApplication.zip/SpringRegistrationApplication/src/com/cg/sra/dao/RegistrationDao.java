package com.cg.sra.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.sra.beans.RegistrationBean;
import com.cg.sra.exception.IDExistsException;

@Repository
@Transactional
public class RegistrationDao implements IRegistrationDao{
	@PersistenceContext
	private EntityManager entityManager;
	@Override
	public RegistrationBean addDetails(RegistrationBean registration) throws IDExistsException {
		
		entityManager.persist(registration);
		entityManager.flush();
		return registration;
		
		
	}
	@Override
	public List<RegistrationBean> getAllDonorsDetails() {
		TypedQuery<RegistrationBean> query = entityManager.createQuery("SELECT d FROM RegistrationBean d", RegistrationBean.class);
	/*	System.out.println(query.getResultList());*/
		return query.getResultList();
		
	}
	@Override
	public RegistrationBean deleteTrainee(Integer empId) {
		
		return entityManager.find(RegistrationBean.class, empId);
	}
	@Override
	public void deleteTraineeDetails(Integer empId) {
	RegistrationBean resistration=entityManager.find(RegistrationBean.class, empId);
		entityManager.remove(resistration);
	}
	@Override
	public RegistrationBean modifyTraineeDetails(Integer empId,
			RegistrationBean trainee) {
		entityManager.find(RegistrationBean.class, empId);
		return entityManager.merge(trainee);
	
	}

}
