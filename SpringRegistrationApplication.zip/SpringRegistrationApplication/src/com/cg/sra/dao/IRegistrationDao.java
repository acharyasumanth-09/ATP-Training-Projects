package com.cg.sra.dao;

import java.util.List;

import com.cg.sra.beans.RegistrationBean;
import com.cg.sra.exception.IDExistsException;

public interface IRegistrationDao {

	RegistrationBean addDetails(RegistrationBean registration) throws IDExistsException;

	List<RegistrationBean> getAllDonorsDetails();

	RegistrationBean deleteTrainee(Integer empId);

	void deleteTraineeDetails(Integer empId);

	RegistrationBean modifyTraineeDetails(Integer empId,
			RegistrationBean trainee);

}
