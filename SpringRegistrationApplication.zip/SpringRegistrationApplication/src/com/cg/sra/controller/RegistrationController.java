package com.cg.sra.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.sra.beans.RegistrationBean;
import com.cg.sra.exception.IDExistsException;
import com.cg.sra.service.IRegistService;





@Controller
public class RegistrationController {
	@Autowired

	private IRegistService service;

	public IRegistService getService() {
		return service;
	}

	public void setService(IRegistService service) {
		this.service = service;
	}
	
	@RequestMapping("/showHomePage")
	public String showHomePage() {
		return "index";
	}
	@RequestMapping("/showRegistration")
public ModelAndView addTrainee() {
		
RegistrationBean registration=new RegistrationBean();
		
		return new ModelAndView("addRegistrationForm", "registration",registration );
	}
	
	@RequestMapping("/addRegistration")
	public ModelAndView addRegistration(
			@ModelAttribute("registration") @Valid RegistrationBean registration,
			BindingResult result) throws IDExistsException {
		
		ModelAndView mv = null;

		if (!result.hasErrors()) {
			try{
			registration = service.addDetails(registration);
			System.out.println(registration.toString());
			mv = new ModelAndView("addSuccess");
			mv.addObject("empId", registration.getEmpId());
	
			/*mv.addObject("empName", registration.getEmpName());
			mv.addObject("salary", registration.getSalary());
			mv.addObject("projName", registration.getProjName());*/
			}catch(Exception e)
			{
				throw new IDExistsException("Id already exist");
			}
		} else {
			mv = new ModelAndView("addRegistrationForm", "registration", registration);
		}

		return mv;
	}
	
	@RequestMapping("/showViewAllRegistrations")
	public ModelAndView showViewAllRegistrations() throws IDExistsException {

		ModelAndView mv = new ModelAndView();
		try{
		List<RegistrationBean> list = service.getAllDonorsDetails();
		System.out.println(list.toString());
		/*if (list.isEmpty()) {
			String msg = "There are no Registrations";
			mv.setViewName("myError");
			mv.addObject("msg", msg);
		} else {*/
			mv.setViewName("viewDetails");
			// Add the attribute to the model
			mv.addObject("list", list);
		}catch(Exception e)
		{
			throw new IDExistsException("There are no Registrations");
		}
		return mv;
	}
	
	@RequestMapping("/DeleteRegistrations")
	public ModelAndView deleteTrainee() {
		RegistrationBean trainee = new RegistrationBean();

		return new ModelAndView("deleteTraineeForm", "trainee", trainee);
	}

	

	@RequestMapping("/deleteTrainee")
	public ModelAndView deleteTrainee(
			@ModelAttribute("trainee") RegistrationBean trainee) throws IDExistsException {
		ModelAndView view = new ModelAndView();
		RegistrationBean trainee1 = new RegistrationBean();
		try{
			trainee1 = service.deleteTrainee(trainee.getEmpId());
			System.out.println(trainee1.toString());
			/*if(trainee1!= null){*/
				view.setViewName("showDeleteDetails");
				view.addObject("trainee1", trainee1);
			/*}else
			{
				String msg = "There are no Registrations with this id";
				view.setViewName("myError");
				view.addObject("msg", msg);
				view.addObject("id", trainee.getEmpId());
			}*/
		}catch(Exception e)
		{
			throw new IDExistsException("Enter the valid id");
		}
		return view;
	}
	
	@RequestMapping("deleteTraineeDetails")
	public ModelAndView deleteTraineeDetails(
		@ModelAttribute("trainee") RegistrationBean trainee) throws IDExistsException {
		ModelAndView view = new ModelAndView();
		try{
			service.deleteTraineeDetails(trainee.getEmpId());
			
				view.setViewName("deleteSuccess");
		}catch(Exception e)
		{
			throw new IDExistsException("There are no Registrations with this id: "+trainee.getEmpId());
		}	
		return view;
	}
	@RequestMapping("/modifyTraineeForms")
	public ModelAndView modifyTraineeForms() {
		RegistrationBean trainee = new RegistrationBean();

		return new ModelAndView("modifyTraineeForm", "trainee", trainee);
	}


	@RequestMapping("/modifyTrainee")
	public ModelAndView modifyTrainee(
			@ModelAttribute("trainee") RegistrationBean trainee) throws IDExistsException {
		ModelAndView view = new ModelAndView();
		RegistrationBean trainee1 = new RegistrationBean();
		try{
			trainee1 = service.deleteTrainee(trainee.getEmpId());
			System.out.println(trainee1.toString());
			/*if(trainee1!= null){*/
				view.setViewName("modifyTraineeDetails");
				
				view.addObject("trainee1", trainee1);
			}catch(Exception e)
			{
				throw new IDExistsException("Enter the valid id");
			}
		return view;
	}
	
	@RequestMapping("modifyTraineeDetails")
	public ModelAndView modifyTraineeDetails(
		@ModelAttribute("trainee") RegistrationBean trainee) throws IDExistsException {
		ModelAndView view = new ModelAndView();
		try{
	/*	RegistrationBean trainee2 =*/ service.modifyTraineeDetails(trainee.getEmpId(),trainee);
			
				view.setViewName("modifySuccess");
				/*view.addObject("traineeId", trainee.getEmpId());
				view.addObject("traineeName", trainee.getEmpName());
				view.addObject("traineeDomain", trainee.getSalary());
				view.addObject("traineeLocation", trainee.getProjName());*/
		}catch(Exception e)
		{
			throw new IDExistsException("There are no Registrations with this id: "+trainee.getEmpId());
		}
		return view;
	}
}
