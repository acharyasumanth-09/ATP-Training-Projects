package com.cg.sra.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.sra.beans.RegistrationBean;
import com.cg.sra.dao.IRegistrationDao;
import com.cg.sra.exception.IDExistsException;
@Service
public class RegistrationService implements IRegistService {
	@Autowired
	IRegistrationDao dao;
	
	
	@Override
	public RegistrationBean addDetails(RegistrationBean registration) throws IDExistsException {
		
		return dao.addDetails(registration);
	}


	@Override
	public List<RegistrationBean> getAllDonorsDetails() {
		
		return dao. getAllDonorsDetails();
	}


	@Override
	public RegistrationBean deleteTrainee(Integer empId) {
		
		return dao.deleteTrainee(empId);
	}


	@Override
	public void deleteTraineeDetails(Integer empId) {
		dao.deleteTraineeDetails(empId);
		
	}




	@Override
	public RegistrationBean modifyTraineeDetails(Integer empId,
			RegistrationBean trainee) {
		
		return dao.modifyTraineeDetails(empId,
				trainee) ;
	}

}
