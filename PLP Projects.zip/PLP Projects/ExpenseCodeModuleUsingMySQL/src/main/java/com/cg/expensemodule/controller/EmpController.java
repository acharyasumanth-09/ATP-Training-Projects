package com.cg.expensemodule.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.expensemodule.bean.ExpenseModule;
import com.cg.expensemodule.service.IExpenseService;

@RestController
@RequestMapping("/emp")
public class EmpController {

	@Autowired
	IExpenseService service;
	
	@RequestMapping(value = "/create")
    public ExpenseModule createExpenseModule(@Valid @RequestBody ExpenseModule expense) {
        return service.createExpenseModule(expense);
    }
	
	@RequestMapping(value="/modify/{expenseCode}")
	private ExpenseModule modifyExpenseDetailsByExpCode(@PathVariable String expenseCode,@Valid @RequestBody ExpenseModule expensemodule){
		expensemodule.setExpenseCode(expenseCode);
		return service.modifyExpenseDetailsByExpCode(expenseCode,expensemodule);
	}
	
	@RequestMapping(value = "/find/{expenseCode}")
	public ExpenseModule getExpenseDetailsByExpCode(@PathVariable String expenseCode) {
		ExpenseModule expensemodule = service.getExpenseDetailsByExpCode(expenseCode);
	    return expensemodule;
	}
	
	@RequestMapping(value="/read")
	public List<ExpenseModule> readExpenseModule(){
		return service.readExpenseModule();
	}

	@RequestMapping(value = "/delete/{expenseCode}")
	public ExpenseModule deleteExpenseDetailsByExpCode(@PathVariable String expenseCode) {
		return service.deleteExpenseDetailsByExpCode(expenseCode);
	}
	
}
