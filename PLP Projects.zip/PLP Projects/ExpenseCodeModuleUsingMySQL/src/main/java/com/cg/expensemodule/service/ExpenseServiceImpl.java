package com.cg.expensemodule.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.expensemodule.bean.ExpenseModule;
import com.cg.expensemodule.dao.IExpenseDao;

@Service
public class ExpenseServiceImpl implements IExpenseService{
	@Autowired
	IExpenseDao dao;

	/* Method Name = createExpenseModule
	 * Arguments = ExpenseModule Object
	 * Author = Capgemini
	 * Creation Date = 07/12/2018
	 * Description = This method is used to Add the Expense Details into the MySQL Database
	 */
	@Override
	public ExpenseModule createExpenseModule(ExpenseModule expensemodule) {
		return dao.createExpenseModule(expensemodule);
	}

	/* Method Name = modifyExpenseDetailsByExpCode
	 * Arguments = String expenseCode & ExpenseModule Object
	 * Author = Capgemini
	 * Creation Date = 07/12/2018
	 * Description = This method is used to Modify or Update the Expense Details of a particular expenseCode present in MySQL Database
	 */
	@Override
	public ExpenseModule modifyExpenseDetailsByExpCode(
			String expenseCode, ExpenseModule expensemodule) {
		return dao.modifyExpenseDetailsByExpCode(expenseCode,expensemodule);
	}
	
	/* Method Name = getExpenseDetailsByExpCode
	 * Arguments = String expenseCode
	 * Author = Capgemini
	 * Creation Date = 07/12/2018
	 * Description = This method is used to fetch the Expense Details of a particular expenseCode from MySQL Database
	 */
	@Override
	public ExpenseModule getExpenseDetailsByExpCode(String expenseCode) {
		return dao.getExpenseDetailsByExpCode(expenseCode);
	}
	
	/* Method Name = readExpenseModule
	 * Arguments = no arguments
	 * Author = Capgemini
	 * Creation Date = 07/12/2018
	 * Description = This method is used to fetch all the Expense Details from MySQL Database
	 */
	@Override
	public List<ExpenseModule> readExpenseModule() {
		return dao.readExpenseModule();
	}

	/* Method Name = deleteExpenseDetailsByExpCode
	 * Arguments = String expenseCode
	 * Author = Capgemini
	 * Creation Date = 07/12/2018
	 * Description = This method is used to delete the Expense Details of a particular expenseCode from MySQL Database
	 */
	@Override
	public ExpenseModule deleteExpenseDetailsByExpCode(String expenseCode) {
		return dao.deleteExpenseDetailsByExpCode(expenseCode);
	}

}
