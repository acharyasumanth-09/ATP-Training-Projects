package com.cg.expensemodule.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.expensemodule.bean.ExpenseModule;
import com.cg.expensemodule.repository.ExpenseRepository;

@Repository
public class ExpenseDaoImpl implements IExpenseDao {
	@Autowired
	ExpenseRepository repository;

	/* Method Name = createExpenseModule
	 * Arguments = ExpenseModule Object
	 * Author = Capgemini
	 * Creation Date = 07/12/2018
	 * Description = This method is used to Add the Expense Details into the MySQL Database
	 */
	@Override
	public ExpenseModule createExpenseModule(ExpenseModule expensemodule) {
		return repository.save(expensemodule);
	}

	/* Method Name = modifyExpenseDetailsByExpCode
	 * Arguments = String expenseCode & ExpenseModule Object
	 * Author = Capgemini
	 * Creation Date = 07/12/2018
	 * Description = This method is used to Modify or Update the Expense Details of a particular expenseCode present in MySQL Database
	 */
	@Override
	public ExpenseModule modifyExpenseDetailsByExpCode(String expenseCode, ExpenseModule expensemodule){
		repository.findOne(expenseCode);
		expensemodule.setExpenseCode(expenseCode);
		repository.save(expensemodule);
		return expensemodule;
	}
	
	/* Method Name = getExpenseDetailsByExpCode
	 * Arguments = String expenseCode
	 * Author = Capgemini
	 * Creation Date = 07/12/2018
	 * Description = This method is used to fetch the Expense Details of a particular expenseCode from MySQL Database
	 */
	@Override
	public ExpenseModule getExpenseDetailsByExpCode(String expenseCode){
		return repository.findOne(expenseCode);
	}
	
	/* Method Name = readExpenseModule
	 * Arguments = no arguments
	 * Author = Capgemini
	 * Creation Date = 07/12/2018
	 * Description = This method is used to fetch all the Expense Details from MySQL Database
	 */
	@Override
	public List<ExpenseModule> readExpenseModule() {
		return repository.findAll();
	}

	/* Method Name = deleteExpenseDetailsByExpCode
	 * Arguments = String expenseCode
	 * Author = Capgemini
	 * Creation Date = 07/12/2018
	 * Description = This method is used to delete the Expense Details of a particular expenseCode from MySQL Database
	 */
	@Override
	public ExpenseModule deleteExpenseDetailsByExpCode(String expenseCode) {
		ExpenseModule expensemodule =repository.findOne(expenseCode);
		 repository.delete(expensemodule);
		 return expensemodule;
	}
	
}

