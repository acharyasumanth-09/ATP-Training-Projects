package com.cg.expensemodule.dao;

import java.util.List;

import com.cg.expensemodule.bean.ExpenseModule;

public interface IExpenseDao {

	ExpenseModule createExpenseModule(ExpenseModule expensemodule);

	ExpenseModule modifyExpenseDetailsByExpCode(String expenseCode, ExpenseModule expensemodule);
	
	ExpenseModule getExpenseDetailsByExpCode(String expenseCode);
	
	List<ExpenseModule> readExpenseModule();
	
	ExpenseModule deleteExpenseDetailsByExpCode(String expenseCode);

}
