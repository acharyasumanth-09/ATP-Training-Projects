package com.cg.expensemodule.service;

import java.util.List;

import com.cg.expensemodule.bean.ExpenseModule;

public interface IExpenseService {

	ExpenseModule createExpenseModule(ExpenseModule expensemodule);

	ExpenseModule modifyExpenseDetailsByExpCode(String expenseCode, ExpenseModule expensemodule);
	
	ExpenseModule getExpenseDetailsByExpCode(String expenseCode);
	
	List<ExpenseModule> readExpenseModule();
	
	ExpenseModule deleteExpenseDetailsByExpCode(String expenseCode);
	
}
