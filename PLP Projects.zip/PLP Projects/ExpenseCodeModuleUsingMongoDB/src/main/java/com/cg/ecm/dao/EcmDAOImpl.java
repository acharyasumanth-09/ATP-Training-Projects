package com.cg.ecm.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.cg.ecm.entity.ExpenseCodeModule;

@Repository
public class EcmDAOImpl implements EcmDAO {

	@Autowired
	private MongoTemplate mongoTemplate;

	/* Method Name = addExpenseDetails
	 * Arguments = ExpenseCodeModule Object
	 * Author = Capgemini
	 * Creation Date = 06/12/2018
	 * Description = This method is used to Add the Expense Details into the MongoDB Database
	 */
	@Override
	public ExpenseCodeModule addExpenseDetails(ExpenseCodeModule expensecodemodule){
		mongoTemplate.save(expensecodemodule);
		return expensecodemodule;
	}
	
	/* Method Name = modifyExpenseDetailsByExpCode
	 * Arguments = ExpenseCodeModule Object
	 * Author = Capgemini
	 * Creation Date = 06/12/2018
	 * Description = This method is used to Modify or Update the Expense Details of a particular expenseCode present in MongoDB Database
	 */
	@Override
	public ExpenseCodeModule modifyExpenseDetailsByExpCode(ExpenseCodeModule expensecodemodule){
		mongoTemplate.save(expensecodemodule);
		return expensecodemodule;
	}
	
	/* Method Name = getExpenseDetailsByExpCode
	 * Arguments = ExpenseCodeModule Object
	 * Author = Capgemini
	 * Creation Date = 06/12/2018
	 * Description = This method is used to fetch the Expense Details of a particular expenseCode from MongoDB Database
	 */
	@Override
	public ExpenseCodeModule getExpenseDetailsByExpCode(String expenseCode){
		Query query = new Query();
		query.addCriteria(Criteria.where("expenseCode").is(expenseCode));
		return mongoTemplate.findOne(query, ExpenseCodeModule.class);
	}
	
	/* Method Name = getAllExpenseDetails
	 * Arguments = no arguments
	 * Author = Capgemini
	 * Creation Date = 06/12/2018
	 * Description = This method is used to fetch all the Expense Details from MongoDB Database
	 */
	@Override
	public List<ExpenseCodeModule> getAllExpenseDetails(){
		return mongoTemplate.findAll(ExpenseCodeModule.class);
	}

	/* Method Name = deleteExpenseDetailsByExpCode
	 * Arguments = String expenseCode
	 * Author = Capgemini
	 * Creation Date = 06/12/2018
	 * Description = This method is used to delete the Expense Details of a particular expenseCode from MongoDB Database
	 */
	@Override
	public ExpenseCodeModule deleteExpenseDetailsByExpCode(String expenseCode){
		ExpenseCodeModule expensecodemodule = getExpenseDetailsByExpCode(expenseCode);
		if(expenseCode != null)
		{
			mongoTemplate.remove(expensecodemodule);
		}
		return expensecodemodule;
	}
	
}
