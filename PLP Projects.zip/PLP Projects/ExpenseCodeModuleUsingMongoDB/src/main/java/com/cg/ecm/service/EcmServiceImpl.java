package com.cg.ecm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ecm.dao.EcmDAO;
import com.cg.ecm.entity.ExpenseCodeModule;

@Service
public class EcmServiceImpl implements EcmService {

	@Autowired
	private EcmDAO ecmDao;

	/* Method Name = addExpenseDetails
	 * Arguments = ExpenseCodeModule Object
	 * Author = Capgemini
	 * Creation Date = 06/12/2018
	 * Description = This method is used to Add the Expense Details into the MongoDB Database
	 */
	@Override
	public ExpenseCodeModule addExpenseDetails(ExpenseCodeModule expensecodemodule){
		return ecmDao.addExpenseDetails(expensecodemodule);
	}
	
	/* Method Name = modifyExpenseDetailsByExpCode
	 * Arguments = ExpenseCodeModule Object
	 * Author = Capgemini
	 * Creation Date = 06/12/2018
	 * Description = This method is used to Modify or Update the Expense Details of a particular expenseCode present in MongoDB Database
	 */
	@Override
	public ExpenseCodeModule modifyExpenseDetailsByExpCode(ExpenseCodeModule expensecodemodule){
		return ecmDao.modifyExpenseDetailsByExpCode(expensecodemodule);
	}
	
	/* Method Name = getExpenseDetailsByExpCode
	 * Arguments = ExpenseCodeModule Object
	 * Author = Capgemini
	 * Creation Date = 06/12/2018
	 * Description = This method is used to fetch the Expense Details of a particular expenseCode from MongoDB Database
	 */
	@Override
	public ExpenseCodeModule getExpenseDetailsByExpCode(String expenseCode){
		return ecmDao.getExpenseDetailsByExpCode(expenseCode);
	}
	
	/* Method Name = getAllExpenseDetails
	 * Arguments = no arguments
	 * Author = Capgemini
	 * Creation Date = 06/12/2018
	 * Description = This method is used to fetch all the Expense Details from MongoDB Database
	 */
	@Override
	public 	List<ExpenseCodeModule> getAllExpenseDetails(){
		return ecmDao.getAllExpenseDetails();
	}

	/* Method Name = deleteExpenseDetailsByExpCode
	 * Arguments = String expenseCode
	 * Author = Capgemini
	 * Creation Date = 06/12/2018
	 * Description = This method is used to delete the Expense Details of a particular expenseCode from MongoDB Database
	 */
	@Override
	public ExpenseCodeModule deleteExpenseDetailsByExpCode(String expenseCode){
		return ecmDao.deleteExpenseDetailsByExpCode(expenseCode);
	}
	
}
