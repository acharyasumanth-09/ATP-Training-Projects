package com.cg.ecm.exception;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.NOT_FOUND)
public class ExpCodeNotFoundException extends RuntimeException {

  public ExpCodeNotFoundException(String exception) {
    super(exception);
  }

}