package com.cg.ecm.service;

import java.util.List;

import com.cg.ecm.entity.ExpenseCodeModule;

public interface EcmService {

	ExpenseCodeModule addExpenseDetails(ExpenseCodeModule expensecodemodule);
	
	ExpenseCodeModule modifyExpenseDetailsByExpCode(ExpenseCodeModule expensecodemodule);
	
	ExpenseCodeModule getExpenseDetailsByExpCode(String expenseCode);

	List<ExpenseCodeModule> getAllExpenseDetails();

	ExpenseCodeModule deleteExpenseDetailsByExpCode(String expenseCode);

}