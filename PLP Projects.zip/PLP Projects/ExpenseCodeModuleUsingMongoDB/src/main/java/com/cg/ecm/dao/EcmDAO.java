package com.cg.ecm.dao;

import java.util.List;

import com.cg.ecm.entity.ExpenseCodeModule;

public interface EcmDAO {

	ExpenseCodeModule addExpenseDetails(ExpenseCodeModule expensecodemodule);
	
	ExpenseCodeModule modifyExpenseDetailsByExpCode(ExpenseCodeModule expensecodemodule);
	
	ExpenseCodeModule getExpenseDetailsByExpCode(String expenseCode);

	List<ExpenseCodeModule> getAllExpenseDetails();

	ExpenseCodeModule deleteExpenseDetailsByExpCode(String expenseCode);

}