package com.cg.ecm.entity;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection="ExpenseCodeModule")
public class ExpenseCodeModule {
	
	@Id
	@Field(value="expenseCode")
	private String expenseCode;
	
	@NotNull(message="Expense Type cannot be empty")
	@Size(min=3,max=15,message="Expense Type should be minimum 3 and maximim 15 characters")
	//@Pattern(regexp = "[A-Z]{1}[a-z]",message="The Expense Type must start with capital character, and should only contain alphabet")
	@Field(value="expenseType")
	private String expenseType;
	
	@NotNull(message="Expense Description cannot be empty")
	@Size(min=15,max=100,message="Expense Description should be minimum 15 and maximim 100 characters")
	//@Pattern(regexp = "^[a-zA-Z0-9_]*$",message="The Expense Description can be combination of alphabets, digits and underscores")
	@Field(value="expenseDescription")
	private String expenseDescription ;
	
	public ExpenseCodeModule() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ExpenseCodeModule(String expenseCode, String expenseType,
			String expenseDescription) {
		super();
		this.expenseCode = expenseCode;
		this.expenseType = expenseType;
		this.expenseDescription = expenseDescription;
	}

	public String getExpenseCode() {
		return expenseCode;
	}

	public void setExpenseCode(String expenseCode) {
		this.expenseCode = expenseCode;
	}

	public String getExpenseType() {
		return expenseType;
	}

	public void setExpenseType(String expenseType) {
		this.expenseType = expenseType;
	}

	public String getExpenseDescription() {
		return expenseDescription;
	}

	public void setExpenseDescription(String expenseDescription) {
		this.expenseDescription = expenseDescription;
	}
}
