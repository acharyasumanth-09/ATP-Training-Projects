package com.cg.ecm.controller;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ecm.entity.ExpenseCodeModule;
import com.cg.ecm.exception.ExpCodeNotFoundException;
import com.cg.ecm.service.EcmService;

@RestController
@RequestMapping(value = "/")
public class EcmController {

	private final Logger LOG = LoggerFactory.getLogger(getClass());

	@Autowired
	private  EcmService ecmService;
	
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public ExpenseCodeModule addExpenseDetails(@Valid @RequestBody ExpenseCodeModule expensecodemodule) {
		LOG.info("Saving Expense Details...");
		return ecmService.addExpenseDetails(expensecodemodule);
	}
	
	@RequestMapping(value="/modify/{expenseCode}",method=RequestMethod.PUT)
	private ExpenseCodeModule modifyExpenseDetailsByExpCode(@PathVariable String expenseCode,@RequestBody ExpenseCodeModule expensecodemodule){
		expensecodemodule.setExpenseCode(expenseCode);
		LOG.info("Modifying Expense Details for Expense Code : {}...",expenseCode);
		return ecmService.modifyExpenseDetailsByExpCode(expensecodemodule);
	}
	
	@RequestMapping(value = "/find/{expenseCode}", method = RequestMethod.GET)
	public ExpenseCodeModule getExpenseDetailsByExpCode(@PathVariable String expenseCode) {
		LOG.info("Getting Expense Details using Expense Code : {}...",expenseCode);
		ExpenseCodeModule expensecodemodule = ecmService.getExpenseDetailsByExpCode(expenseCode);
	    if(expensecodemodule == null)
	    {
	    	throw new ExpCodeNotFoundException("Expense Code Not Found");
	    }
	    return expensecodemodule;
	}
	
	@RequestMapping(value = "/viewAll", method = RequestMethod.GET)
	public List<ExpenseCodeModule> getAllExpenseDetails() {
		LOG.info("Getting all Expense Details...");
		return ecmService.getAllExpenseDetails();
	}
	
	@RequestMapping(value = "/delete/{expenseCode}", method = RequestMethod.DELETE)
	public ExpenseCodeModule deleteExpenseDetailsByExpCode(@PathVariable String expenseCode) {
		LOG.info("Deleting Expense Details...");
		return ecmService.deleteExpenseDetailsByExpCode(expenseCode);
	}

}

