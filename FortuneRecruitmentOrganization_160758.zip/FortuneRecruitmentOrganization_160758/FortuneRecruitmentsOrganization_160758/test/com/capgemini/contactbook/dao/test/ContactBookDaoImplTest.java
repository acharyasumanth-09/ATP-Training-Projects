package com.capgemini.contactbook.dao.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exceptions.ContactBookException;
import com.igate.contactbook.bean.EnquiryBean;

public class ContactBookDaoImplTest {

	ContactBookDaoImpl contactbookdaoimpl = null;
	
	@Before
	public void setUp() throws Exception {
		contactbookdaoimpl = new ContactBookDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
		contactbookdaoimpl = null;
	}

	@Test
	public void testAddEnquiry() {
		EnquiryBean enquirybean = new EnquiryBean("Ranjit", "Sharma", "9876567008", "Mumbai", "Java");
		try {
			int result = contactbookdaoimpl.addEnquiry(enquirybean);
			assertEquals(1, result);
		} catch (ContactBookException e) {
			e.printStackTrace();
		}
	}
	

	@Test
	public void testAddEnquiryNull() {
		EnquiryBean enquirybean = new EnquiryBean("Ranjit", "Sharma", "9876567008", "Mumbai", "Java");
		try {
			int result = contactbookdaoimpl.addEnquiry(enquirybean);
			assertNotNull(enquirybean);
		} catch (ContactBookException e) {
			e.printStackTrace();
		}
	}

}
