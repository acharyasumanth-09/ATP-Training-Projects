package com.capgemini.contactbook.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.contactbook.exceptions.ContactBookException;
import com.capgemini.contactbook.service.ContactBookService;
import com.capgemini.contactbook.service.ContactBookServiceImpl;
import com.igate.contactbook.bean.EnquiryBean;

public class Client {
	
	static Logger logger = Logger.getLogger(Client.class);
	static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		
		ContactBookService contactbookservice = new ContactBookServiceImpl();
		
		PropertyConfigurator.configure("resources/log4j.properties");
		logger.info("log4j configured");
		
		System.out.println("*******************Fortune Recruitments******************");
		System.out.println("\n");
		System.out.println("Choose an operation");
		System.out.println("1. Enter Enquiry Details");
		System.out.println("2. Exit");
		System.out.println("*********************************************************");
		
		System.out.println("Please enter a choice:");
		int option = 0;
		
		try{
			option = scanner.nextInt();
		}catch(InputMismatchException e){
			System.err.println("Enter digits only either 1 or 2");
			System.exit(0);
		}
		
		switch(option){
			
		case 1:EnquiryBean enquirybean = openEnquiry();
		try{
		boolean result = contactbookservice.isValidEnquiry(enquirybean);
			if(result){
				int resultFlag = contactbookservice.addEnquiry(enquirybean);
				if(resultFlag == 1){
					int enqId = contactbookservice.getMaxEnqryId();
					System.out.println("Thank you "+enquirybean.getfName()+" "+enquirybean.getIName()+" your Unique Id is "+enqId+" we will contact you shortly.");
				}else{
					System.out.println("Enquiry not Added");
				}
			}
		}catch(ContactBookException e){
			System.err.println(e.getMessage());
		}
		break;
		
		case 2:System.out.println("Thank you for selecting us!");
				System.exit(0);
		
		default: System.out.println("Invalid Input");
				 break;
		}	
	}

	private static EnquiryBean openEnquiry() {
		scanner.nextLine();
		System.out.println("Enter First Name:");
		String fName = scanner.nextLine();
		System.out.println("Enter Last Name:");
		String lName = scanner.nextLine();
		System.out.println("Enter Contact Number:");
		String contactNo = scanner.nextLine();
		System.out.println("Enter Preferred Domain");
		String pDomain = scanner.nextLine();
		System.out.println("Enter Preferred Location:");
		String pLocation = scanner.nextLine();
		
		EnquiryBean enquirybean = new EnquiryBean(fName, lName, contactNo, pLocation, pDomain);
		return enquirybean;
	}

}
