package com.capgemini.contactbook.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.contactbook.dao.ContactBookDao;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exceptions.ContactBookException;
import com.igate.contactbook.bean.EnquiryBean;

public class ContactBookServiceImpl implements ContactBookService{
	
	ContactBookDao contactbookdao = new ContactBookDaoImpl();
	
	/*
	 * methodName = addEnquiry
	 * arguments = EnquiryBean object
	 * returnType = int
	 * author = Capgemini
	 * creationDate = 05/11/2018
	 * description = this method is used to insert the enquiries into the database 
	 */
	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {
		return contactbookdao.addEnquiry(enqry) ;
	}

	/*
	 * methodName = isValidEnquiry
	 * arguments = EnquiryBean object
	 * returnType = boolean
	 * author = Capgemini
	 * creationDate = 05/11/2018
	 * description = this method is used for validation of the data entered by user 
	 */
	@Override
	public boolean isValidEnquiry(EnquiryBean enqry)
			throws ContactBookException {
		boolean flag = false;
		List<String> list = new ArrayList<>();
		if (!isFirstNameValid(enqry.getfName())) {
			list.add("\n First Name should contain only alphabets and should not be empty.");
		}

		if (!isLastNameValid(enqry.getIName())) {
			list.add("\n Last Name should contain only alphabets and should not be empty.");
		}
		
		if (!isContactNumberValid(enqry.getContactNo())) {
			list.add("\n Contact Number should be a 10 digits valid mobile number only and should not be empty.");
		}

		if (!isPreferredDomainValid(enqry.getpDomain())) {
			list.add("\n Preferred Domain should contain only alphabets and should not be empty.");
		}
		
		if (!isPreferredLocationValid(enqry.getpLocation())) {
			list.add("\n Preferred Location should contain only alphabets and should not be empty.");
		}

		if (!list.isEmpty()) {
			list.add("\n List is empty");
			flag = true;
		}
		return flag;
	}


	public boolean isFirstNameValid(String fname) {
		String fnameRegEx = "[A-Za-z]{4,30}";
		Pattern pattern = Pattern.compile(fnameRegEx);
		Matcher matcher = pattern.matcher(fname);
		return matcher.matches();
	}
	

	public boolean isLastNameValid(String lname) {
		String lnameRegEx = "[A-Za-z]{4,30}";
		Pattern pattern = Pattern.compile(lnameRegEx);
		Matcher matcher = pattern.matcher(lname);
		return matcher.matches();
	}
	
	public boolean isContactNumberValid(String contactNo) {
		String contactNumberRegEx = "[0-9]{10}";
		Pattern pattern = Pattern.compile(contactNumberRegEx);
		Matcher matcher = pattern.matcher(contactNo);
		return matcher.matches();
	}
	
	public boolean isPreferredDomainValid(String pDomain) {
		String pDomainRegEx = "[A-Za-z]{1,40}";
		Pattern pattern = Pattern.compile(pDomainRegEx);
		Matcher matcher = pattern.matcher(pDomain);
		return matcher.matches();
	}
	
	public boolean isPreferredLocationValid(String pLocation) {
		String pLocationRegEx = "[A-Za-z]{1,40}";
		Pattern pattern = Pattern.compile(pLocationRegEx);
		Matcher matcher = pattern.matcher(pLocation);
		return matcher.matches();
	}

	/*
	 * methodName = getMaxEnqryId
	 * arguments = no arguments
	 * returnType = int
	 * author = Capgemini
	 * creationDate = 05/11/2018
	 * description = this method is used to get the auto generated enquiryId from the database 
	 */
	@Override
	public int getMaxEnqryId() throws ContactBookException {
		return contactbookdao.getMaxEnqryId();
	}

}
