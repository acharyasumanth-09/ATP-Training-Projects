package com.capgemini.contactbook.dao;

public interface QueryConstants {

	public static final String addEnquiry = "insert into enquiry values(enquiries_sql.nextval,?,?,?,?,?)";

	public static final String getMaxEnqryId = "select max(enqryId) from enquiry";
}
