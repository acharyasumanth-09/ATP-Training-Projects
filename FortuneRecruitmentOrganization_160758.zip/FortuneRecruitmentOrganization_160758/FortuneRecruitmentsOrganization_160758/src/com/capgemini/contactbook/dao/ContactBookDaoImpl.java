package com.capgemini.contactbook.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.contactbook.exceptions.ContactBookException;
import com.capgemini.contactbook.utility.jdbcUtility;
import com.igate.contactbook.bean.EnquiryBean;

public class ContactBookDaoImpl implements ContactBookDao {

	static Logger logger = Logger.getLogger(ContactBookDaoImpl.class);
	Connection connection = null;
	PreparedStatement statement = null;
	
	/*
	 * methodName = addEnquiry
	 * arguments = EnquiryBean object
	 * returnType = int
	 * author = Capgemini
	 * creationDate = 05/11/2018
	 * description = this method is used to insert the enquiries into the database 
	 */
	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {
		connection = jdbcUtility.getConnection();
		logger.info("Connection Established");
		int flag = 0;
		
		try {
			statement = connection.prepareStatement(QueryConstants.addEnquiry);
			logger.debug("Statement Created");
			statement.setString(1, enqry.getfName());
			statement.setString(2, enqry.getIName());
			statement.setString(3, enqry.getContactNo());
			statement.setString(4, enqry.getpDomain());
			statement.setString(5, enqry.getpLocation());
			
			int result = statement.executeUpdate();
			if(result > 0){
				logger.debug("Enquiry Added into the Database");
				flag = 1;
			}
		} catch (SQLException e) {
			logger.debug("Statement object not created");
			throw new ContactBookException("Statement not created due to some problems");
		}finally{
			jdbcUtility.closeConnection();
		}
		return flag;
	}

	/*
	 * methodName = getMaxEnqryId
	 * arguments = no arguments
	 * returnType = int
	 * author = Capgemini
	 * creationDate = 05/11/2018
	 * description = this method is used to get the auto generated enquiryId from the database 
	 */
	@Override
	public int getMaxEnqryId() throws ContactBookException {
		int enqId = 0;
		ResultSet resultSet = null;
		connection = jdbcUtility.getConnection();
		
		try {
			statement = connection.prepareStatement(QueryConstants.getMaxEnqryId);
			resultSet = statement.executeQuery();
			resultSet.next();
			enqId = resultSet.getInt(1);
		} catch (SQLException e) {
			throw new ContactBookException("Unable to Create the Statement");
		}finally{
			try {
				resultSet.close();
			} catch (SQLException e) {
				throw new ContactBookException("Some Problem occured while closing the resultSet");
			}
			try {
				statement.close();
			} catch (SQLException e) {
				throw new ContactBookException("Some Problem occured while closing the statement");
			}
			jdbcUtility.closeConnection();
		}
		return enqId;
	}
}
