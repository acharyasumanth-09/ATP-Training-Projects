package com.cg.tms.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.tms.beans.TraineeBean;
import com.cg.tms.beans.login;
import com.cg.tms.exception.IDExistsException;
import com.cg.tms.service.ITraineeService;

@Controller
public class TraineeContoller {
	@Autowired
	ITraineeService traineeService;

	
	public ITraineeService getTraineeService() {
		return traineeService;
	}
	public void setTraineeService(ITraineeService traineeService) {
		this.traineeService = traineeService;
	}
	@RequestMapping("/showlogin")
	public String showHomePage() {
		return "login";
	}
	@RequestMapping("/showmenu")
	public ModelAndView showmenu(@ModelAttribute("login") login login)
	{
		login login1=new login();
		ModelAndView mv=new ModelAndView();
		String uname=login.getUserName();
		String password=login.getPassword();
		
		if(uname.equals(login1.getUserName()) && password.equals(login1.getPassword()))
		{
			mv.setViewName("menu");
		}
		else
		{
			mv.setViewName("login");
		}
		return mv;
		
	}
	@RequestMapping("/showAddTrainee")
	public ModelAndView showAddTrainee() {
		// Create an attribute of type Question
		TraineeBean trainee = new TraineeBean();
		// Add the attribute to the model and set the viewname and return it
		return new ModelAndView("addTraineeForm", "trainee", trainee);
	}
	
	@RequestMapping("/addTrainee")
	public ModelAndView addTrainee(
			@ModelAttribute("trainee") @Valid TraineeBean trainee,
			BindingResult result) throws IDExistsException {

		ModelAndView mv = null;
		if(result.hasErrors())
		{
			mv.setViewName("addTraineeForm");
		}
		else
		{
			try{
			trainee = traineeService.addTrainee(trainee);
			mv = new ModelAndView("addSuccess");
			mv.addObject("traineeId", trainee.getTraineeId());
			}
			catch(Exception ex)
			{
				throw new IDExistsException("id not  exists");
			}
		}

		/*if (!result.hasErrors()) {
			trainee = traineeService.addTrainee(trainee);
			mv = new ModelAndView("addSuccess");
			mv.addObject("traineeId", trainee.getTraineeId());
			
		} else {
			mv = new ModelAndView("addTraineeForm", "trainee", trainee);
		}*/

		return mv;
	}
	
	
	@RequestMapping("/showViewTraineeForm")
	public ModelAndView showViewTraineeForm() {

		
		TraineeBean trainee = new TraineeBean();
		// Add the attribute to the model and return along with
		// the view name
		ModelAndView mv = new ModelAndView("viewTrainee");
		mv.addObject("trainee", trainee);
		mv.addObject("isFirst", "true");

		return mv;
	}

	@RequestMapping("/viewTrainee")
	public ModelAndView viewTrainee(  @ModelAttribute("trainee") TraineeBean trainee) {

		ModelAndView mv = new ModelAndView();

		TraineeBean dBean = new TraineeBean();
		dBean = traineeService.getTraineeDetails(trainee.getTraineeId());

		if (dBean != null) {
			mv.setViewName("viewTrainee");
			mv.addObject("dBean", dBean);
		} else {
			String msg = "Enter a Valid Id!!";
			mv.setViewName("myError");
			mv.addObject("msg", msg);
			/*throw new RuntimeException("enter a valid id");*/
		}

		return mv;
	}
	
	@RequestMapping("/showViewAllTrainee")
	public ModelAndView showViewAllTrainee() {

		ModelAndView mv = new ModelAndView();

		List<TraineeBean> list = traineeService.getAllTraineeDetails();
		if (list.isEmpty()) {
			String msg = "There are no Trainees";
			mv.setViewName("myError");
			mv.addObject("msg", msg);
		} else {
			mv.setViewName("viewAlltraineeList");
			// Add the attribute to the model
			mv.addObject("list", list);
		}
		return mv;
	}
	
	@RequestMapping("/showDeleteTrainee")
	public ModelAndView deleteTrainee() {
		TraineeBean trainee = new TraineeBean();

		return new ModelAndView("deleteTraineeForm", "trainee", trainee);
	}

	@RequestMapping("showDeleteDetails")
	public ModelAndView showDeleteDetails() {
		TraineeBean trainee = new TraineeBean();

		return new ModelAndView("showDeleteDetails", "trainee", trainee);
	}

	@RequestMapping("/deleteTrainee")
	public ModelAndView deleteTrainee(
			@ModelAttribute("trainee") TraineeBean trainee) {
		ModelAndView view = new ModelAndView();
		TraineeBean trainee1 = new TraineeBean();
			trainee1 = traineeService.deleteTrainee(trainee.getTraineeId());
			if(trainee1!= null){
				view.setViewName("showDeleteDetails");
				view.addObject("trainee1", trainee1);
			}
			else
			{
				String msg = "There are no records on this id";
				view.setViewName("myError");
				view.addObject("msg", msg);
			}
		return view;
	}
	
	@RequestMapping("/deleteTraineeDetails")
	public ModelAndView deleteTraineeDetails(
		@ModelAttribute("trainee") TraineeBean trainee) {
		ModelAndView view = new ModelAndView();
		traineeService.deleteTraineeDetails(trainee.getTraineeId());
			
				view.setViewName("deleteSuccess");
			
		return view;
	}
	
	
	@RequestMapping("/showModifyTrainee")
	public ModelAndView modifyTraineeForms() {
		TraineeBean trainee = new TraineeBean();

		return new ModelAndView("modifyTraineeForm", "trainee", trainee);
	}


	@RequestMapping("/modifyTrainee")
	public ModelAndView modifyTrainee(
			@ModelAttribute("trainee") TraineeBean trainee) {
		ModelAndView view = new ModelAndView();
		TraineeBean trainee1 = new TraineeBean();
			trainee1 = traineeService.deleteTrainee(trainee.getTraineeId());
			if(trainee1!= null){
				view.setViewName("modifyTraineeDetails");
				
				view.addObject("trainee1", trainee1);
			}
			else
			{
				String msg = "There are no records on this id to modify";
				view.setViewName("myError");
				view.addObject("msg", msg);
			}
		return view;
	}
	
	@RequestMapping("/modifyTraineeDetails")
	public ModelAndView modifyTraineeDetails(
		@ModelAttribute("trainee") TraineeBean trainee) {
		ModelAndView view = new ModelAndView();
		TraineeBean trainee2 = traineeService.modifyTraineeDetails(trainee.getTraineeId(),trainee);
			
				view.setViewName("modifySuccess");
				view.addObject("traineeId", trainee.getTraineeId());
				view.addObject("traineeName", trainee.getTraineeName());
				view.addObject("traineeDomain", trainee.getTraineeDomain());
				view.addObject("traineeLocation", trainee.getTraineeLocation());
		
		return view;
	}
	
}
