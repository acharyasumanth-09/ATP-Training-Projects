package com.cg.tms.exception;


import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

@ControllerAdvice
public class TraineeException {
	@ExceptionHandler(value=Exception.class)
	public ModelAndView message( Exception ex, HttpServletRequest req)
	{
		ModelAndView mv=new ModelAndView();
		String Response = ex.getMessage();
		String uri = req.getRequestURL().toString();
        ErrorInfo errorInfo = new ErrorInfo(uri, Response);
		
		
		mv.addObject("msg",errorInfo);
		mv.setViewName("myError");
		return mv;
		
	}
	
	
}
