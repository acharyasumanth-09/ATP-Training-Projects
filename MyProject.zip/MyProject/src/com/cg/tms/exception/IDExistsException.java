package com.cg.tms.exception;

public class IDExistsException extends Exception {
 /**
	 * 
	 */
	private static final long serialVersionUID = -4015585497155435515L;
public String message;
	public String getMessage() {
	return message;
}
public void setMessage(String message) {
	this.message = message;
}
	public IDExistsException(String message) {
	super(message);
	
}
	public IDExistsException() {
		super();
		
		
	
	}
	
	

}
