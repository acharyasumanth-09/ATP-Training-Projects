package com.cg.tms.dao;

import java.util.List;

import com.cg.tms.beans.TraineeBean;

public interface ITraineeDao {

	TraineeBean addTrainee(TraineeBean trainee);

	TraineeBean getTraineeId(int traineeId);

	TraineeBean getTraineeDetails(int traineeId);

	List<TraineeBean> getAllTraineeDetails();

	TraineeBean deleteTrainee(int traineeId);

	void deleteTraineeDetails(int traineeId);

	TraineeBean modifyTraineeDetails(int traineeId, TraineeBean trainee);

}
