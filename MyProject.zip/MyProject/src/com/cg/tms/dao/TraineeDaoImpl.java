package com.cg.tms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.tms.beans.TraineeBean;
@Repository
@Transactional
public class TraineeDaoImpl implements ITraineeDao{
	@PersistenceContext
	private EntityManager entityManager;
	public TraineeBean addTrainee(TraineeBean trainee) {		
		entityManager.persist(trainee);
		entityManager.flush();
		return trainee;
	}
	@Override
	public TraineeBean getTraineeId(int traineeId) {
		return entityManager.find(TraineeBean.class, traineeId);
	}
	@Override
	public TraineeBean getTraineeDetails(int traineeId) {
		return entityManager.find(TraineeBean.class, traineeId);
		
	}
	@Override
	public List<TraineeBean> getAllTraineeDetails() {
		TypedQuery<TraineeBean> query = entityManager.createQuery("SELECT d FROM TraineeBean d", TraineeBean.class);
		
		return query.getResultList();
	}
	@Override
	public TraineeBean deleteTrainee(int traineeId) {
		
		return entityManager.find(TraineeBean.class, traineeId);
	}
	@Override
	public void deleteTraineeDetails(int traineeId) {
		TraineeBean trainee1=entityManager.find(TraineeBean.class, traineeId);
		entityManager.remove(trainee1);
		
	}
	@Override
	public TraineeBean modifyTraineeDetails(int traineeId, TraineeBean trainee) {
		entityManager.find(TraineeBean.class, traineeId);
		return entityManager.merge(trainee);	
	}

	
	
}
