package com.cg.tms.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="Trainee_Info_Table")
public class TraineeBean {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer traineeId;
	
	@NotEmpty(message="Please Enter Trainee Name")
	@Size(min=4,max=8,message="Minimum 4 and Maximum 8 characters required")
	@Pattern(regexp = "^[a-zA-Z]+$", message = "Trainee Name must contain only alphabets")
	private String traineeName;
	
	@NotEmpty(message="Please Choose a Trainee Domain")
	@Pattern(regexp = "^[a-zA-Z]+$", message = "Trainee domain must contain only alphabets")
	private String traineeDomain;
	
	@NotEmpty(message="Please Choose a Trainee Location")
	@Pattern(regexp = "^[a-zA-Z]+$", message = "Trainee location must contain only alphabets")
	private String traineeLocation;

	public Integer getTraineeId() {
		return traineeId;
	}

	public void setTraineeId(Integer traineeId) {
		this.traineeId = traineeId;
	}

	public String getTraineeName() {
		return traineeName;
	}

	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}

	public String getTraineeDomain() {
		return traineeDomain;
	}

	public void setTraineeDomain(String traineeDomain) {
		this.traineeDomain = traineeDomain;
	}

	public String getTraineeLocation() {
		return traineeLocation;
	}

	public void setTraineeLocation(String traineeLocation) {
		this.traineeLocation = traineeLocation;
	}

	@Override
	public String toString() {
		return "Trainee [traineeId=" + traineeId + ", traineeName="
				+ traineeName + ", traineeDomain=" + traineeDomain
				+ ", traineeLocation=" + traineeLocation + "]";
	}

	public TraineeBean(int traineeId, String traineeName, String traineeDomain,
			String traineeLocation) {
		super();
		this.traineeId = traineeId;
		this.traineeName = traineeName;
		this.traineeDomain = traineeDomain;
		this.traineeLocation = traineeLocation;
	}
	
	public TraineeBean(String traineeName, String traineeDomain,
			String traineeLocation) {
		super();
		this.traineeName = traineeName;
		this.traineeDomain = traineeDomain;
		this.traineeLocation = traineeLocation;
	}

	public TraineeBean() {
		// TODO Auto-generated constructor stub
	}
}
