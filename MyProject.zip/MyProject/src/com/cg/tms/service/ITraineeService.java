package com.cg.tms.service;

import java.util.List;

import com.cg.tms.beans.TraineeBean;

public interface ITraineeService {

	TraineeBean addTrainee(TraineeBean trainee);

	TraineeBean getTraineeDetails(int traineeId);

	List<TraineeBean> getAllTraineeDetails();

	TraineeBean deleteTrainee(int traineeId);

	void deleteTraineeDetails(int traineeId);

	TraineeBean modifyTraineeDetails(int traineeId, TraineeBean trainee);

}
