package com.cg.tms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.tms.beans.TraineeBean;
import com.cg.tms.dao.ITraineeDao;
@Service
public class TraineeServiceImpl implements ITraineeService{
	@Autowired
ITraineeDao traineedao;
	public ITraineeDao getTraineedao() {
	return traineedao;
}
public void setTraineedao(ITraineeDao traineedao) {
	this.traineedao = traineedao;
}
	@Override
	public TraineeBean addTrainee(TraineeBean trainee) {
		return traineedao.addTrainee(trainee);
	}
	public TraineeBean getTraineeId(int traineeId) {
		return traineedao.getTraineeId(traineeId);
	}
	@Override
	public TraineeBean getTraineeDetails(int traineeId) {
		
		return traineedao.getTraineeDetails(traineeId);
	}
	@Override
	public List<TraineeBean> getAllTraineeDetails() {
		
		return traineedao.getAllTraineeDetails();
	}
	@Override
	public TraineeBean deleteTrainee(int traineeId) {
		// TODO Auto-generated method stub
		return traineedao.deleteTrainee(traineeId);
	}
	@Override
	public void deleteTraineeDetails(int traineeId) {
		// TODO Auto-generated method stub
		traineedao.deleteTraineeDetails(traineeId);
	}
	@Override
	public TraineeBean modifyTraineeDetails(int traineeId, TraineeBean trainee) {
		
		return traineedao.modifyTraineeDetails(traineeId, trainee);
	}
}
