package com.cg.oqa.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.oqa.bean.QuizBean;
import com.cg.oqa.service.IQuestionService;

@Controller
public class QuizController {

	@Autowired
	IQuestionService service;
	
	
	public IQuestionService getService() {
		return service;
	}
	public void setService(IQuestionService service) {
		this.service = service;
	}
	@RequestMapping("/home")
	public String home() {
		return "home";
	}
	@RequestMapping("/addForm")
	public ModelAndView addQuestionForm() {
		QuizBean bean=new QuizBean();
		return  new ModelAndView("Add_Questions","bean", bean);
	}
	@RequestMapping("success")
	public ModelAndView addSuccess(@ModelAttribute("bean") @Valid QuizBean bean ,BindingResult result){
		
		ModelAndView view=null;
		if(result.hasErrors()){
			view = new ModelAndView("Add_Questions","bean", new QuizBean());
		}
		else
		{
			service.addQuestion(bean);
			view = new ModelAndView("success");
			view.addObject("questionId", bean.getQues_no());
		}
		return view;
				
	}
}
