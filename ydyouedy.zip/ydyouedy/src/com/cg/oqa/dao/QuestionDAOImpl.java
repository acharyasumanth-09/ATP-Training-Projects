package com.cg.oqa.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.oqa.bean.QuizBean;

@Repository
@Transactional
public class QuestionDAOImpl  implements IQuestionDAO{

	@PersistenceContext
	private EntityManager manager;

	@Override
	public void addQuestion(QuizBean bean) {
		manager.persist(bean);
		
	}
}
