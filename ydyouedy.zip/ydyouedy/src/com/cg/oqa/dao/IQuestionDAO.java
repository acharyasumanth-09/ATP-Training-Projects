package com.cg.oqa.dao;

import com.cg.oqa.bean.QuizBean;

public interface IQuestionDAO {

	void addQuestion(QuizBean bean);

}
