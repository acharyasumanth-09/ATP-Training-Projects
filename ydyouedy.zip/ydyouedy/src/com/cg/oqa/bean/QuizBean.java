package com.cg.oqa.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

@Entity
@Table(name="Question_Master")
public class QuizBean {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO )
	private Integer Ques_no;
	private String Ques_subtopic;
	private String Ques_category;
	@NotEmpty(message = "Cannot be empty")
	@Pattern(regexp = "[A-Z]{1}[a-z]{2,}", message = "Name should start with capitals only!!")
	private String Question;
	@NotEmpty(message = "Cannot be empty")
	private String Option1;
	@NotEmpty(message = "Cannot be empty")
	private String Option2;
	@NotEmpty(message = "Cannot be empty")
	private String Option3;
	@NotEmpty(message = "Cannot be empty")
	private String Option4;
	@Range(min=1,max=4,message="should be in between 1 and 4")
	private Integer Answer;
	private int Review_cnt;
	public Integer getQues_no() {
		return Ques_no;
	}
	public void setQues_no(Integer Ques_no) {
		this.Ques_no = Ques_no;
	}
	public String getQues_subtopic() {
		return Ques_subtopic;
	}
	public void setQues_subtopic(String ques_subtopic) {
		Ques_subtopic = ques_subtopic;
	}
	public String getQues_category() {
		return Ques_category;
	}
	public void setQues_category(String ques_category) {
		Ques_category = ques_category;
	}
	public String getQuestion() {
		return Question;
	}
	public void setQuestion(String question) {
		Question = question;
	}
	public String getOption1() {
		return Option1;
	}
	public void setOption1(String option1) {
		Option1 = option1;
	}
	public String getOption2() {
		return Option2;
	}
	public void setOption2(String option2) {
		Option2 = option2;
	}
	public String getOption3() {
		return Option3;
	}
	public void setOption3(String option3) {
		Option3 = option3;
	}
	public String getOption4() {
		return Option4;
	}
	public void setOption4(String option4) {
		Option4 = option4;
	}
	public Integer getAnswer() {
		return Answer;
	}
	public void setAnswer(Integer answer) {
		Answer = answer;
	}
	public int getReview_cnt() {
		return Review_cnt;
	}
	public void setReview_cnt(int review_cnt) {
		Review_cnt = review_cnt;
	}
	@Override
	public String toString() {
		return "QuizBean [questionId=" + Ques_no + ", Ques_subtopic="
				+ Ques_subtopic + ", Ques_category=" + Ques_category
				+ ", Question=" + Question + ", Option1=" + Option1
				+ ", Option2=" + Option2 + ", Option3=" + Option3
				+ ", Option4=" + Option4 + ", Answer=" + Answer
				+ ", Review_cnt=" + Review_cnt + "]";
	}
	public QuizBean(String ques_subtopic, String ques_category,
			String question, String option1, String option2, String option3,
			String option4, Integer answer, int review_cnt) {
		super();
		Ques_subtopic = ques_subtopic;
		Ques_category = ques_category;
		Question = question;
		Option1 = option1;
		Option2 = option2;
		Option3 = option3;
		Option4 = option4;
		Answer = answer;
		Review_cnt = review_cnt;
	}
	
	public QuizBean() {
		// TODO Auto-generated constructor stub
	}

}
