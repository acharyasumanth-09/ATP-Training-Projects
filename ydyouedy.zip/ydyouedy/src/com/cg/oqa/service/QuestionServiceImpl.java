package com.cg.oqa.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.oqa.bean.QuizBean;
import com.cg.oqa.dao.IQuestionDAO;

@Service
public class QuestionServiceImpl implements IQuestionService{
	@Autowired
	IQuestionDAO dao ;

	@Override
	public void addQuestion(QuizBean bean) {
		dao.addQuestion(bean);
		
	}

}
