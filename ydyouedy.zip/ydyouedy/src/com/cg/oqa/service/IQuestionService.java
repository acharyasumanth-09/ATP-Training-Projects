package com.cg.oqa.service;

import com.cg.oqa.bean.QuizBean;

public interface IQuestionService {

	void addQuestion(QuizBean bean);

}
