package com.cg.ems.service;

import com.cg.ems.beans.EmployeeBeans;
import com.cg.ems.beans.LoginBean;

public interface IEmployeeService {

	EmployeeBeans addEmployee(EmployeeBeans employee);

	LoginBean getLogin(String username);

}
