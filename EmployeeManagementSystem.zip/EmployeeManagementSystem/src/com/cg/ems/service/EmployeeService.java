package com.cg.ems.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ems.beans.EmployeeBeans;
import com.cg.ems.beans.LoginBean;
import com.cg.ems.dao.IEmployeeDao;
@Service
public class EmployeeService implements IEmployeeService {
	
	@Autowired
	IEmployeeDao dao;
	
	public IEmployeeDao getDao() {
		return dao;
	}

	public void setDao(IEmployeeDao dao) {
		this.dao = dao;
	}

	@Override
	public EmployeeBeans addEmployee(EmployeeBeans employee) {
		
		return dao.addDetails(employee);
	}

	@Override
	public LoginBean getLogin(String username) {
		
		return dao.getLogin(username);
	}

}
