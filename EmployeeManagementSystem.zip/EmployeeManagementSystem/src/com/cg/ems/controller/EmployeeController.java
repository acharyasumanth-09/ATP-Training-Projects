package com.cg.ems.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ems.beans.EmployeeBeans;
import com.cg.ems.beans.LoginBean;
import com.cg.ems.exceptions.CustomException;
import com.cg.ems.service.IEmployeeService;

@Controller
public class EmployeeController {
	@Autowired
	IEmployeeService service;

	public IEmployeeService getService() {
		return service;
	}

	public void setService(IEmployeeService service) {
		this.service = service;
	}

	@RequestMapping("/showLoginPage")
	public ModelAndView loginForm() {
		LoginBean bean = new LoginBean();
		return new ModelAndView("login", "bean", bean);
	}

	@RequestMapping("/login")
	public ModelAndView login(@ModelAttribute("login") @Valid LoginBean bean,
			BindingResult result) throws CustomException {
		ModelAndView model = null;
		if (!result.hasErrors()) {
			try {
				LoginBean beans = service.getLogin(bean.getUsername());
				if (beans.getUsername().equals(bean.getUsername())
						&& beans.getPassword().equals(bean.getPassword())) {
					model = new ModelAndView("index");
				} else {

					model = new ModelAndView("login", "bean", bean);
				}
			} catch (Exception e) {
				throw new CustomException("Invalid Credentials");
			}
		} else {
			model = new ModelAndView("login", "bean", bean);
		}
		return model;
	}

	@RequestMapping("/showHomePage")
	public String showHomePage() {
		return "index";
	}

	@RequestMapping("/addEmpForm")
	public ModelAndView addEmpForm() {
		EmployeeBeans employee = new EmployeeBeans();
		return new ModelAndView("empform", "employee", employee);
	}

	@RequestMapping("/addEmployees")
	public ModelAndView addEmployees(
			@ModelAttribute("employee") @Valid EmployeeBeans employee,
			BindingResult result) {

		ModelAndView modelView = null;
		if (!result.hasErrors()) {
			employee = service.addEmployee(employee);
			modelView = new ModelAndView("addSuccess");
			modelView.addObject("employeeId", employee.getId());
			modelView.addObject("employeeName", employee.getName());
			modelView.addObject("employeeSalary", employee.getSalary());
			modelView.addObject("employeeDepartment", employee.getDepartment());
			modelView.addObject("projectName", employee.getProjectName());
		} else {
			modelView = new ModelAndView("empform", "employee", employee);
		}
		return modelView;
	}

}
