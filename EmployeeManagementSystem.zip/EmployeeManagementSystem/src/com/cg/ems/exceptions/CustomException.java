package com.cg.ems.exceptions;

public class CustomException  extends Exception{
	private static final long serialVersionUID = 1L;
	
	public CustomException() {
	}
	public CustomException(String arg0) {
		super(arg0);
	}
	
}
