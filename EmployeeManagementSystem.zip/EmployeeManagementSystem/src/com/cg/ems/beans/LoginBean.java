package com.cg.ems.beans;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="login_beans")
public class LoginBean {
	@Id	
	@Pattern(regexp="[a-z0-9+@_]{4,}",message="Username contains alphanumeric and special chracters!!")
	@NotEmpty
	private String username;
	@Pattern(regexp="[A-Za-z0-9+@]{4,}",message="Password contains alphanumeric and special chracters!!")
	@NotEmpty
	private String password;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public LoginBean(String username, String password) {
		super();
		this.username = username;
		this.password = password;
	}

	public LoginBean() {
		// TODO Auto-generated constructor stub
	}

}
