package com.cg.ems.beans;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Range;

import com.sun.istack.internal.NotNull;

@Entity
@Table(name="Table_beans")
public class EmployeeBeans {
	@Id
	@Range(min=100000,max=999999,message="ID should be equal to 6 digits")
	private Integer id;
	@Pattern(regexp="[A-Z]{1}[a-z]{2,}",message="Name should start with Capital letter only!!")
	@NotNull
	private String name;
	@Range(min=1,message="salary must be greater than 0")
	private Double salary;
	@Pattern(regexp="[a-z]{2,}",message="Name should start with Capital letter only!!")
	@NotNull
	private String department;
	@Pattern(regexp="[a-z]{2,}",message="Name should start with Capital letter only!!")
	@NotNull
	private String projectName;

	public EmployeeBeans() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmployeeBeans(Integer id, String name, Double salary,
			String department, String projectName) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.department = department;
		this.projectName = projectName;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getSalary() {
		return salary;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

}
