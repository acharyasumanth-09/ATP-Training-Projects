package com.cg.ems.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.ems.beans.EmployeeBeans;
import com.cg.ems.beans.LoginBean;
@Repository
@Transactional
public class EmployeeDao implements IEmployeeDao {

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public EmployeeBeans addDetails(EmployeeBeans employee) {
		
		entityManager.persist(employee);
		entityManager.flush();
		return employee;
	}

	@Override
	public LoginBean getLogin(String username) {
		LoginBean beans=entityManager.find(LoginBean.class, username);
		return beans;
	}

}
