package com.cg.ems.dao;

import com.cg.ems.beans.EmployeeBeans;
import com.cg.ems.beans.LoginBean;

public interface IEmployeeDao {

	EmployeeBeans addDetails(EmployeeBeans employee);

	LoginBean getLogin(String username);

}
