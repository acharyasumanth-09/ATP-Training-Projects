package com.cg.fms.service;

import java.util.List;

import org.apache.log4j.Logger;

import com.cg.fms.dao.FeedbackDaoIMPL;
import com.cg.fms.dao.IFeedbackDao;
import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.CourseFacultyMapBean;
import com.cg.fms.model.CourseMasterBean;
import com.cg.fms.model.FacultySkillMasterBean;
import com.cg.fms.model.LoginBean;
import com.cg.fms.model.TrainingProgramDetails;
import com.cg.fms.model.TrainingProgramMaintain;
import com.cg.fms.model.feedbackBean;
import com.cg.fms.model.participantEnroll;
import com.cg.fms.model.viewFeedbackMaster;

public class FeedbackServiceIMPL implements IFeedbackService {
	
	IFeedbackDao dao=new FeedbackDaoIMPL();
	@Override
	public String checkRole(LoginBean login) throws FMSException {
	
		return dao.checkRole(login);
	}
	@Override
	public int insertFacultySkill(FacultySkillMasterBean facultySkill) throws FMSException {
		return dao.insertFacultySkill(facultySkill);
	}
	@Override
	public int updateFacultySkillOper(FacultySkillMasterBean facultyupdateSkill) throws FMSException {
		return dao.updateFacultySkillOper(facultyupdateSkill);
	}
	@Override
	public int deletefacultySkilloper(String facultyId) throws FMSException {
		return dao.deletefacultySkilloper(facultyId);
	}
	@Override
	public List<FacultySkillMasterBean> viewAllFacultyDetails() throws FMSException {
		return dao.viewAllFacultyDetails();
	}
	@Override
	public List<CourseFacultyMapBean> viewMapDetails() throws FMSException {
		return dao.viewMapDetails();
	}
	@Override
	public int insertCourseDetails(CourseMasterBean courseBean) throws FMSException {
		return dao.insertCourseDetails(courseBean);
	}
	@Override
	public int updateCourseOper(CourseMasterBean courseBean1) throws FMSException {
		return dao.updateCourseOper(courseBean1);
	}
	@Override
	public int deleteCourseoper(String courseId) throws FMSException {
		return dao.deleteCourseoper(courseId);
	}
	@Override
	public List<CourseMasterBean> viewAllCourseDetails() throws FMSException {
		return dao.viewAllCourseDetails();
	}
	@Override
	public List<TrainingProgramMaintain> fetchingTrainingProgramDetails() throws FMSException {
		return dao.fetchingTrainingProgramDetails();
	}
	@Override
	public boolean getTrainingCode(String trainingCode) throws FMSException {
		return dao.getTrainingCode(trainingCode);
	}
	@Override
	public boolean checkParticipantId(String participantId ,String trainingCode) throws FMSException {
		return dao.checkParticipantId(participantId , trainingCode);
	}
	@Override
	public int insertFeedback(feedbackBean fbBean) throws FMSException {
		return dao.insertFeedback(fbBean);
	}
	@Override
	public String getParticipantId(LoginBean login) throws FMSException {
		return dao.getParticipantId(login);
	}
	@Override
	public int insertParticipant(participantEnroll penroll) throws FMSException {
		return dao.insertParticipant(penroll);
	}
	@Override
	public List<viewFeedbackMaster> viewAllFeedbackDetails() throws FMSException {
		return dao.viewAllFeedbackDetails();
	}
	@Override
	public String fetchfacultyId(String trainingCode) throws FMSException {
		return dao.fetchfacultyId(trainingCode);
	}
	@Override
	public int insertTrainingProgram(TrainingProgramDetails trainingprogram) throws FMSException {
		
		return dao.insertTrainingProgram(trainingprogram);
	}
	
	
	

}
