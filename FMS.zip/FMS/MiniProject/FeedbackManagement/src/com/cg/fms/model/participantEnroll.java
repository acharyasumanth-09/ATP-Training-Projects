package com.cg.fms.model;

public class participantEnroll {
	
	
	private String trainingCode;
	private String participantId;
	public participantEnroll(String trainingCode, String participantId) {
		super();
		this.trainingCode = trainingCode;
		this.participantId = participantId;
	}
	public String getTrainingCode() {
		return trainingCode;
	}
	public void setTrainingCode(String trainingCode) {
		this.trainingCode = trainingCode;
	}
	public String getParticipantId() {
		return participantId;
	}
	public void setParticipantId(String participantId) {
		this.participantId = participantId;
	}
	public participantEnroll() {
		// TODO Auto-generated constructor stub
	}

}
