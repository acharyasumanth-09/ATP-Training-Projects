package com.cg.fms.model;

public class TrainingProgramDetails {

	private String trainingCode;
	private String courseId;
	private String facultyId;
	private String startDate;
	private String endDate;
	public String getTrainingCode() {
		return trainingCode;
	}
	public void setTrainingCode(String trainingCode) {
		this.trainingCode = trainingCode;
	}
	public String getCourseId() {
		return courseId;
	}
	public void setCourseId(String courseId) {
		this.courseId = courseId;
	}
	public String getFacultyId() {
		return facultyId;
	}
	public void setFacultyId(String facultyId) {
		this.facultyId = facultyId;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public TrainingProgramDetails(String trainingCode, String courseId,
			String facultyId, String startDate, String endDate) {
		super();
		this.trainingCode = trainingCode;
		this.courseId = courseId;
		this.facultyId = facultyId;
		this.startDate = startDate;
		this.endDate = endDate;
	}
	@Override
	public String toString() {
		return "TrainingProgramDetails [trainingCode=" + trainingCode
				+ ", courseId=" + courseId + ", facultyId=" + facultyId
				+ ", startDate=" + startDate + ", endDate=" + endDate + "]";
	}
	public TrainingProgramDetails() {
		// TODO Auto-generated constructor stub
	}
}
